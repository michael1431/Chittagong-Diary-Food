<strong class="">Copyright &copy; 2018-2019 <a href="http://ringersoft.com/">Ringer Soft</a>.</strong>
<span class="">All rights reserved.</span>
<div class="float-right d-none d-sm-inline-block ">
    <b>Version</b> 1.0.1
</div>