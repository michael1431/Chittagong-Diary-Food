





















@extends('layouts.fixed')

@section('title','Item - Inventory CDF ')

@section('content')
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Manage  Item  </h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Settings</a></li>
                        <li class="breadcrumb-item active">Manage Sales Return  </li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->


    <!-- Main content -->
    <section class="content">
        <div class="col-lg-12">
            <div class="row">
                {{--create/edit start --}}
                
                {{--create/edit  start --}}

                {{--list  start --}}
                <div class="col-md-12">
                    <div class="card card-warning card-outline">
                        <div class="card-header">
                            <div class="card-title">
                                <h5 class="text-info">@if(request('order_history'))
                    <a class="btn btn-xs btn-info" href="{{route('view-order')}}">View Pending Order</a>
                    @else
                    <a class="btn btn-xs btn-info" href="{{route('view-order',['order_history=1'])}}">View Order History</a>
                    @endif</h5>
                            </div>

                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-widget="collapse">
                                    <i class="fas fa-minus"></i>
                                </button>
                            </div>
                            <!-- /.card-tools -->
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body" style="display: block; min-height: 707px;">
                            <div class="table-responsive">
                        <center><caption><h2>Order List</h2></caption></center>
                            <table class="table-bordered table-striped table" id="myTable1">
                                <thead>
                                    <th>#SL</th>
                                    <th>Order No</th>
                                    <th>Total Amount</th>
                                    <th>OrderBy</th>
                                    @if(request('order_history'))
                                    <th>SoldBy</th>
                                    @endif
                                    <th>Status</th>
                                    <th>Order Date</th>
                                    <th>Action</th>
                                </thead>

                                <tbody>
                                    @php $i=0; @endphp
                                    @if($invoices->count()>0)
                                        @foreach($invoices as $invoice)
                                            <tr>
                                                <td>{{ ++$i }}</td>
                                                <td width="11%">{{ $invoice->invoice_no }}</td>
                                                <td>{{ $invoice->total_amount }}</td>
                                                <td>{{ $invoice->related_party_type=='Customer' ? $invoice->order_by->name : '' }}</td>
                                                @if(request('order_history'))
                                                    <td>{{ $invoice->user->name }}</td>
                                                @endif
                                                <td>
                                                    @if($invoice->status==0)
                                                        <label class='label label-danger check_label'>Pending</label> 
                                                    @else 
                                                    <a href="{{ route('invoice.print',[$invoice->id,'chalan'=>1]) }}">
                                                        <label class='label label-success check_label'> Delivered </label>
                                                    @endif
                                                </td>
                                                <td> 
                                                    {{ \Carbon\Carbon::parse($invoice->created_at)->format('D-d-M-Y')   }}  -- {{ $invoice->created_at->diffForHumans() }}
                                                </td>
                                                <td>
                                                    <a class=" {{ $invoice->status ==0 ? "fa fa-eye btn btn-danger" : "fa fa-eye  btn btn-success" }}" href="{{ $invoice->status ==0 ? route('invoice-show',$invoice->id) : route('invoice.print',$invoice->id) }}"></a>
                                                    @if($invoice->status)
                                                        <a class="far fa-minus-circle btn btn-info" href="{{ route('invoice-return',$invoice->id) }}">View</a>
                                                    @endif
                                                </td>
                                            </tr>
                                       @endforeach
                                    @endif
                                </tbody>
                            </table>
                        </div>
                        </div>
                        <!-- /.card-body -->
                    </div>
                </div>
                {{--list end--}}

            </div>
        </div>

    </section><!-- /.content -->
@stop

@section('style')
    <!-- DataTables -->
    <link rel="stylesheet" href="{{ asset('plugins/datatables/dataTables.bootstrap4.css') }}">
@stop

@section('plugin')
    <!-- DataTables -->
    <script src="{{ asset('plugins/datatables/jquery.dataTables.js') }}"></script>
    <script src="{{ asset('plugins/datatables/dataTables.bootstrap4.js') }}"></script>
@stop

@section('script')
    <!-- page script -->
    <script type="text/javascript">
        var table;
        $(document).ready(function () {
            $('#myTable1').dataTable();
        });


        $(document).on("change",".department_id",function () {
            var group_id = $(this).val();

            $('#productTable').dataTable({
                'destroy': true,
                'paging': true,
                'searching': true,
                'processing': true,
                'serverSide': true,
                'serverMethod': 'post',
                'paginate':true,
                "paginType": "full_numbers",
                "aLengthMenu": [10,100,200,500],
                "stateSave": true,
                "ajax": {
                    'url': '{{ route('groupwise.productList') }}',
                    'data': { group_id:group_id,_token:'{{ csrf_token() }}'},
                },
                "columns": [
                    { "data": "sl" },
                    { "data": "code" },
                    { "data": "name" },
                    { "data": "group" },
                    { "data": "unit" },
                    { "data": "department" },
                    { "data": "price" },
                    { "data": "description" },
                    { "data": "edit" }
                ]
            });
        });

      /*  $(document).on("change",".department_id",function () {
            var group_id = $(this).val();
            table.clear().draw();
            var row = "<tr> <td colspan='9' style='background: red;padding: 10px;color: #fff3cd;font-size: 1rem;text-align: center;'> Please wait item loading ............. </td>  </tr>";
            $("#tbodyItem").html(row);

            $.ajax({
                method:"post",
                url : "{{ route('groupwise.productList') }}",
                data : { group_id:group_id,_token:'{{ csrf_token() }}'},
                dataType:'json',
                success:function (response) {
                    for (var i=0;i<response.success.sl.length;i++){
                        table.row.add([
                            response.success.sl[i],
                            response.success.code[i],
                            response.success.name[i],
                            response.success.department[i],
                            response.success.group[i],
                            response.success.unit[i],
                            response.success.price[i],
                            response.success.description[i],
                            response.success.edit[i]
                        ]).draw();
                    }
                }
            })
        });*/


        /* datatable Ajax Processing start */



        /* Datatable Ajax Processing End */

    </script>
@stop