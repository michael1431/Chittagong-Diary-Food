

<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Dashboard</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Dashboard v1</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">

            <!-- Small boxes (Stat box) -->
            <div class="row" id="print_portion4">
                <div class="col-lg-3 col-6">
                    <!-- small box -->
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3><?php echo e($todaysCosts->sum('total_amount')); ?> <sup style="font-size: 20px">৳</sup></h3>

                            <p>Today's Expense</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-bag"></i>
                        </div>
                        <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <!-- ./col -->
                <div class="col-lg-3 col-6">
                    <!-- small box -->
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3><?php echo e($pending_orders->count()); ?> <sup style="font-size: 20px">No</sup></h3>

                            <p>Today's Pending Order</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-stats-bars"></i>
                        </div>
                        <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <!-- ./col -->
                <div class="col-lg-3 col-6">
                    <!-- small box -->
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3><?php echo e($todays_sales); ?> <sup style="font-size: 20px">৳</sup></h3>

                            <p>Today's Sales</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-person-add"></i>
                        </div>
                        <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <!-- ./col -->
                <div class="col-lg-3 col-6">
                    <!-- small box -->
                    <div class="small-box bg-info">
                        <div class="inner">
                            <h3><?php echo e($todays_purchase); ?> <sup style="font-size: 20px">৳</sup></h3>
                            <p>Today's Purchase</p>
                        </div>
                        <div class="icon">
                            <i class="ion ion-pie-graph"></i>
                        </div>
                        <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <div class="text-right no-print" id="btn_print4">
                    <button class="btn btn-primary" onclick="printData(4)"><i class="fa fa-print"></i></button>
                </div>
                <!-- ./col -->
            </div>
            <!-- /.row -->
             <!-- Small boxes (Stat box) -->
             <div class="row">
                <div class="col-lg-6 col-6" id="print_portion2">
                   
                        <div class="card o-hidden mb-4">
                            <div class="card-header">
                                <h3 class="w-50 float-left card-title m-0">Today's Expenses</h3>
                                <div class="dropdown dropleft text-right w-50 float-right">
                                    <button class="btn bg-gray-100" type="button" id="dropdownMenuButton_table4"
                                        data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="nav-icon i-Gear-2"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">  
                                    <table id="expense_table" class="table table-bordered text-center">
                                        <thead>
                                            <tr>
                                                <th scope="col">#</th>
                                                <th scope="col">Date</th>
                                                <th scope="col">Details</th>
                                                <th scope="col">Amount</th>
                                                <th scope="col">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $todaysCosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$ex): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <th scope="row"><?php echo e($key+1); ?></th>
                                                <td><?php echo e(\Carbon\Carbon::parse($ex->created_at)->format('d-M-Y')); ?></td>
                                                <td>
    
                                                    <?php echo e($ex->cost->name); ?>

    
                                                </td>
    
                                                <td><?php echo e($ex->total_amount); ?></td>
                                                <td>
                                                    <a href="<?php echo e(route('invoice.print',$ex->id)); ?>" class="btn btn-info"><i class="fa fa-eye"></i></a>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                
                                            <?php endif; ?>
                                           
                                           
    
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="cart-footer">
                                <div class="text-right no-print" id="btn_print2">
                                    <button class="btn btn-primary" onclick="printData(2)"><i class="fa fa-print"></i></button>
                                </div>
                            </div>
                        </div>
                    
                </div>
                <div class="col-lg-6 col-6" id="print_portion3">
                    <div class="card o-hidden mb-4">
                        <div class="card-header">
                            <h3 class="w-50 float-left card-title m-0">Today's Sales</h3>
                            <div class="dropdown dropleft text-right w-50 float-right">
                                           <button class="btn bg-gray-100" type="button" id="dropdownMenuButton_table4"
                                            data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="nav-icon i-Gear-2"></i>
                                        </button>
                            </div>

                        </div>
                        <div class="card-body">

                            <div class="table-responsive">
                                
                                <table id="order_table" class="table table-bordered text-center">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Date</th>
                                            <th scope="col">OrderBy</th>
                                            <th scope="col">Amount</th>
                                            <th scope="col">Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $pending_orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$pendingOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <th scope="row"><?php echo e($key+1); ?></th>
                                            <td><?php echo e(\Carbon\Carbon::parse($pendingOrder->created_at)->format('d-M-Y')); ?></td>
                                            <td>

                                                <?php echo e($pendingOrder->order_by->name); ?>


                                            </td>

                                            <td><?php echo e($pendingOrder->total_amount); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('invoice.print',$pendingOrder->id)); ?>" class="btn btn-info"><i class="fa fa-eye"></i></a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            
                                        <?php endif; ?>
                                       
                                       

                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="cart-footer">
                            <div class="text-right no-print" id="btn_print3">
                                <button class="btn btn-primary" onclick="printData(3)"><i class="fa fa-print"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12" id="print_portion1">
                <div class="card"><br>
                    <div class="card-header">
                        <h3 class="w-50 float-left card-title m-0">Today's Transactions</h3>
                        <div class="dropdown dropleft text-right w-50 float-right">
                            <button class="btn bg-gray-100" type="button" id="dropdownMenuButton_table4"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="nav-icon i-Gear-2"></i>
                            </button>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-lg-12 table-responsive">
                                <table class="table-bordered table-striped table">
                                    <thead>
                                        <th>#SL</th>
                                        <th>Invoice No</th>
                                        <th>Party</th>
                                        <th>Event</th>
                                        <th>Total</th>                                    
                                        <th>Commission</th>                                   
                                        <th>Paid/Received</th>
                                        <th>Action</th>
                                    </thead>
    
                                   
                                    <tbody>
                                        <?php 
                                            $i=0;
                                            $total=0;
                                        ?>
                                        <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
                                            <tr>
                                                <td><?php echo e(++$i); ?></td>
                                                <td><?php echo e($invoice_info->invoice_no); ?></td>
                                                
                                                <?php if($invoice_info->related_party_type !== null && $invoice_info->related_party_type == 'Customer'): ?>
                                                    <td><strong class="badge badge-success"> Customer </strong>  <?php echo e($invoice_info->order_by->name ?? 'N/A'); ?></td>
                                                  
                                                <?php elseif($invoice_info->related_party_type !== null && $invoice_info->related_party_type == 'Supplier'): ?>
                                                    <td><strong class="badge badge-info"> Supplier </strong>   <?php echo e($invoice_info->supplier->name ?? 'N/A'); ?></td>
    
                                                <?php elseif($invoice_info->related_party_type !== null && $invoice_info->related_party_type == 'Employee'): ?>
                                                    <td><strong class="badge badge-warning"> Employee </strong>   <?php echo e($invoice_info->employee->name ?? 'N/A'); ?></td>
                                        
                                                <?php else: ?>
                                                    <td>
                                                        <strong class="badge badge-danger"> Expenses </strong>
                                                        <?php echo e($invoice_info->cost->name ?? 'N/A'); ?>

                                                       
                                                    </td>
                                                <?php endif; ?>
                                                
                                                <td><?php echo e(strtoupper($invoice_info->event)); ?></td>
                                                <td><?php echo e($invoice_info->total_amount); ?></td>
                                                <td><?php echo e($invoice_info->total_discount); ?></td>
                                                
                                                <td><?php echo e($invoice_info->total_paid); ?></td>
                                                
                                                <td>
                                                        <a href="<?php echo e(route('invoice.print',$invoice_info->id)); ?>" class="btn btn-info"><i class="fa fa-eye"></i></a>
                                                        
    
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                </table>
                            </div>
                            
    
                        </div>
                    </div>
                    <div class="cart-footer">
                        <div class="text-right no-print" id="btn_print1">
                            <button class="btn btn-primary" onclick="printData(1)"><i class="fa fa-print"></i></button>
                        </div>
                    </div>
                </div>
            </div>
            </div>

            

        </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script type="text/javascript">
        $(document).ready(function () {
            $('#expense_table').DataTable();
        });
        function printData(numVar) {
        $('#btn_print'+numVar).hide();
        var contentPrint = document.getElementById('print_portion'+numVar).innerHTML;
        var contentOrg = document.body.innerHTML;
        document.body.innerHTML = contentPrint;
        window.print();
        document.body.innerHTML = contentOrg;
        $('#btn_print'+numVar).show();
       
    }
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugin-css'); ?>
    <!-- iCheck -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/iCheck/flat/blue.css')); ?>">
    <!-- Morris chart -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/morris/morris.css')); ?>">
    <!-- jvectormap -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/jvectormap/jquery-jvectormap-1.2.2.css')); ?>">
    <!-- Date Picker -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/datepicker/datepicker3.css')); ?>">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/daterangepicker/daterangepicker-bs3.css')); ?>">
    <!-- bootstrap wysihtml5 - text editor -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugin'); ?>
    <!-- jQuery UI 1.11.4 -->
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
    <!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
    <script>
        $.widget.bridge('uibutton', $.ui.button)
    </script>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/fontawesome-free-5.6.3-web/js/all.min.css')); ?>">
    <!-- Morris.js charts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="<?php echo e(asset('plugins/morris/morris.min.js')); ?>"></script>
    <!-- Sparkline -->
    <script src="<?php echo e(asset('plugins/sparkline/jquery.sparkline.min.js')); ?>"></script>
    <!-- jvectormap -->
    <script src="<?php echo e(asset('plugins/jvectormap/jquery-jvectormap-1.2.2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/jvectormap/jquery-jvectormap-world-mill-en.js')); ?>"></script>
    <!-- jQuery Knob Chart -->
    <script src="<?php echo e(asset('plugins/knob/jquery.knob.js')); ?>"></script>
    <!-- daterangepicker -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.10.2/moment.min.js"></script>
    <script src="<?php echo e(asset('plugins/daterangepicker/daterangepicker.js')); ?>"></script>
    <!-- datepicker -->
    <script src="<?php echo e(asset('plugins/datepicker/bootstrap-datepicker.js')); ?>"></script>
    <!-- Bootstrap WYSIHTML5 -->
    <script src="<?php echo e(asset('plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js')); ?>"></script>
    <!-- Slimscroll -->
    <script src="<?php echo e(asset('plugins/slimScroll/jquery.slimscroll.min.js')); ?>"></script>
    <!-- FastClick -->
    <script src="<?php echo e(asset('plugins/fastclick/fastclick.js')); ?>"></script>
    <!-- AdminLTE dashboard demo (This is only for demo purposes) -->
    <script src="<?php echo e(asset('dist/js/pages/dashboard.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fixed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ringersoft/cdf.ringersoft.com/resources/views/dashboard/index.blade.php ENDPATH**/ ?>