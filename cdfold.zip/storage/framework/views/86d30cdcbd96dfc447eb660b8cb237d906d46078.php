<div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('details', 'Supplier Name', ['class'=>'label-control'])); ?>

    <?php echo e(Form::text('name',old('name'),['class'=>'form-control','placeholder'=>'Enter Party / Supplier name','autofocus','required'])); ?>


    <?php if($errors->has('name')): ?>
        <span class="help-block text-center" id="success-alert">
            <strong><?php echo e($errors->first('name')); ?></strong>
        </span>
    <?php endif; ?>
</div>


<div class="form-group<?php echo e($errors->has('phone') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('details', 'Supplier Phone', ['class'=>'label-control'])); ?>

    <?php echo e(Form::text('phone',old('phone'),['class'=>'form-control','placeholder'=>'Ex. 01800-000000','autofocus','required'])); ?>


    <?php if($errors->has('phone')): ?>
        <span class="help-block text-center" id="success-alert">
            <strong><?php echo e($errors->first('phone')); ?></strong>
        </span>
    <?php endif; ?>
</div>

<div class="form-group<?php echo e($errors->has('details') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('details', 'Supplier Address', ['class'=>'label-control'])); ?>

    <?php echo e(Form::textarea('address',old('details'),['class'=>'form-control','placeholder'=>'Shortly Brief about Party/Supplier address','rows'=>5,'cols'=>5])); ?>


    <?php if($errors->has('details')): ?>
        <span class="help-block">
            <strong><?php echo e($errors->first('details')); ?></strong>
        </span>
    <?php endif; ?>
</div>

<div class="form-group">
    <div class="">
        <?php echo e(Form::submit($save, ['class'=>'btn btn-success btn-block'])); ?>

    </div>
</div><?php /**PATH /home/ringersoft/cdf.ringersoft.com/resources/views/inventory/supplier/form-supplier-inventory.blade.php ENDPATH**/ ?>