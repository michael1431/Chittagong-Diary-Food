<?php $__env->startSection('title','Dues Status  - CDF '); ?>
<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Dues Report</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Reports</a></li>
                        <li class="breadcrumb-item active">Dues Report</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!--.content-header-->

    <!-- Main content -->
    <section class="content">
        <div class="col-lg-12">
            <div class="row">
                
                <div class="col-lg-12">
                    <div class=" bg-light">
                        <div class="card card-info card-outline">
                            <div class="card-header">
                                <h3 class="card-title">Search Dues Report</h3>
                                <div class="card-tools">
                                    <button type="button" class="btn btn-tool" data-widget="collapse">
                                        <i class="fas fa-plus"></i>
                                    </button>
                                </div>
                            </div> <!-- /.card-header -->

                            <div class="card-body" style="display: block;">
                                <div class="row">
                                    <div class="col-lg-3">
                                        <?php echo e(Form::open(['route'=>'parties.status','method'=>'get','enctype'=>'multipart/form-data','id'=>'report_form'])); ?>

                                            <div class="col-lg-12">
                                                <div class="form-group">
                                                    <?php echo e(Form::label('type','Choose Type: ',['class'=>'control-label'])); ?>

                                                    <?php echo e(Form::select('type',['Customer'=>'Customer','Supplier'=>'Supplier'],null,['class'=>'form-control ','placeholder'=>'Select Customer or Supplier','required','id'=>'type'])); ?>

                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="form-group">
                                                        <?php echo e(Form::label('related_party','Select Customer / Supplier : ',['class'=>'control-label'])); ?>

                                                        <select id="related_party" name="related_party" class="form-control">

                                                        </select>
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="form-group">
                                                        <?php echo e(Form::label("date","Date:",['class'=>'control-label'])); ?>

                                                        <div class="input-daterange input-group" id="datepicker">
                                                            <?php echo e(Form::text('start',old('start'),['class'=>'form-control','id'=>'start','placeholder'=>'From','required'])); ?>

                                                            <span class="input-group-addon">to</span>
                                                            <?php echo e(Form::text('end',old('end'),['class'=>'form-control','id'=>'end','placeholder'=>'To','required'])); ?>


                                                        </div>
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="form-group">
                                                    <button class="btn btn-info form-control" type="submit" id="show_report_customerSupplier">
                                                        Show Report
                                                    </button>
                                                </div>
                                            </div>
                                            <?php echo e(Form::close()); ?>

                                            <hr>
                                            <?php if(count($parties)>0): ?>

                                            <?php echo e(Form::open(['route'=>'parties.changeDuesStatus','method'=>'post','enctype'=>'multipart/form-data','id'=>'report_form'])); ?>

                                            <fieldset>
                                                <legend style="border:solid 1px black;border-radius:10%">If You Want to  <?php echo e($parties->first()->related_party_type=='Supplier'? 'Pay '.$parties->first()->supplier->name : 'Receive from '.$parties->first()->customer->name); ?></legend>
                                            <div class="col-lg-12">
                                                <div class="form-group">
                                                        <?php echo e(Form::label('amount', $parties->first()->related_party_type=='Supplier'? 'Pay Amount' : 'Receive Amount' ,['class'=>'control-label'])); ?>

                                                        <?php echo e(Form::number('amount',0,['class'=>'form-control','required'=>'required'])); ?>

                                                        <?php if($errors->has('amount')): ?>
                                                            <span class="help-block">
                                                                 <strong><?php echo e($errors->first('amount')); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                        <?php echo e(Form::label('amount','Note' ,['class'=>'control-label'])); ?>

                                                        <?php echo e(Form::text('note',null,['class'=>'form-control'])); ?>

                                                        <?php if($errors->has('note')): ?>
                                                            <span class="help-block">
                                                                 <strong><?php echo e($errors->first('note')); ?></strong>
                                                            </span>
                                                        <?php endif; ?>
                                                        <?php echo e(Form::hidden('party_id',$parties->first()->related_party_id,['class'=>'form-control','required'=>'required'])); ?>

                                                        <?php echo e(Form::hidden('party_type',$parties->first()->related_party_type,['class'=>'form-control','required'=>'required'])); ?>

                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="form-group">
                                                        <?php echo e(Form::button($parties->first()->related_party_type=='Supplier'? 'Paid' : 'Collect',['type'=>'submit','id'=>'savekarat','class'=>'btn btn-primary'])); ?>

                                                </div>
                                            </div>
                                            </fieldset>
                                            <?php echo e(Form::close()); ?>

                                            <?php endif; ?>
                                    </div>
                                    <div class="col-lg-9 table-responsive" style="background: #ffffff;" id="print_portion">
                                            <?php if(count($parties)>0): ?>
                                            <div class="panel">
                                                <div class="panel-heading" style="background: #fff">
                                                        <h1 class="text-center text-uppercase text-thin mar-no"><?php echo e(company_info()->company_name); ?></h1>
                                                        <h1 class="h4 panel-title text-center">Ledger Statement</h1>
                                                <p class="text-center"><b><?php echo e(request('start') ? date('d-M-Y',strtotime(request('start'))):'--'); ?> To <?php echo e(request('end') ? date('d-M-Y',strtotime(request('end'))):''); ?></b></p>
                                                </div>
                                                <hr>
                                                <div class="panel-body">
                                            <caption class="align-center"><h3 class="text-center"><?php echo e($parties->first()->related_party_type=='Supplier' ? $parties->first()->supplier->name : $parties->first()->customer->name); ?> 's Report</h3></caption>
                                            <table class="table table-bordered table-striped">



                                                <thead>
                                                <tr>
                                                    <th>sl</th>
                                                    <th>Invoice</th>
                                                    <th>Date</th>
                                                    <th>Event</th>
                                                    <th>Billed Amount</th>
                                                    <th><?php echo e($parties->first()->related_party_type=='Supplier'? 'Discount' : 'Commission'); ?></th>
                                                    <th><?php echo e($parties->first()->related_party_type=='Supplier'? 'Paid' : 'Received'); ?></th>
                                                    <th>Product Returned</th>
                                                    <th><?php echo e($parties->first()->related_party_type=='Supplier'? 'Payable' : 'Receivable'); ?></th>
                                                </tr>
                                                </thead>
                                                <tbody id="dues_report">
                                                    <?php
                                                        $continue=0;
                                                    ?>
                                                    <?php $__empty_1 = true; $__currentLoopData = $parties; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $party): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                        <tr>
                                                        <td><?php echo e($key+1); ?></td>
                                                            <td><?php echo e($party->invoice_no); ?></td>
                                                            <td><?php echo e(date('d-m-Y',strtotime($party->created_at))); ?></td>
                                                            <td><?php echo e($party->event); ?>

                                                                <?php if($party->note): ?>
                                                                    <br>[<?php echo e($party->note); ?>]
                                                                <?php endif; ?>
                                                            </td>
                                                            <td class="text-right"><?php echo e(number_format($party->total_amount,2)); ?></td>
                                                            <td class="text-right"><?php echo e(number_format($party->total_discount,2)); ?></td>
                                                            <td class="text-right"><?php echo e(number_format($party->total_paid,2)); ?></td>
                                                            <td class="text-right"><?php echo e(number_format($party->total_less,2)); ?></td>
                                                            <?php
                                                                $continue+=$party->total_amount-$party->total_discount-$party->total_paid-$party->total_less
                                                            ?>
                                                            <td class="text-right"><?php echo e(number_format($continue,2)); ?></td>

                                                        </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                                    <?php endif; ?>
                                                </tbody>
                                                <tr>
                                                <td colspan="7" class="text-right">Total</td>
                                                <td class="text-right"><?php echo e(number_format($continue,2)); ?></td>
                                                </tr>
                                            </table>
                                            </div>
                                            <?php endif; ?>
                                    </div>
                                    <div class="text-right no-print" id="btn_print">
                                        <button class="btn btn-primary" onclick="printData()"><i class="fa fa-print"></i></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                



            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugin'); ?>
    <!-- DataTables -->
    <script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.js')); ?>"></script>

    <!-- page script -->
    <script type="text/javascript">

        $(document).ready(function(){
            $('#datepicker').datepicker({
                format: 'yyyy-mm-dd'
            });
            $("#protable").DataTable();
            $("#related_party").select2({
                placeholder: 'Select Supllier or Customer'
            });
        });

        $('#type').change(function () {
            var type = $(this).val();

            $.ajax({
                method:"post",
                url:"<?php echo e(route('report.load_parties')); ?>",
                data:{type:type,_token:"<?php echo e(csrf_token()); ?>"},
                success:function (response) {
                    $("#related_party").html(response);
                },
                error:function (err) {
                    console.log(err);
                }
            });
        });

        function printData() {
        $('#btn_print').hide();
        //$('#show_report_customerSupplier').hide();
        var contentPrint = document.getElementById('print_portion').innerHTML;
        var contentOrg = document.body.innerHTML;
        document.body.innerHTML = contentPrint;
        window.print();
        document.body.innerHTML = contentOrg;
        $('#btn_print').show();
        //$('#show_report_customerSupplier').show();
    }



    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fixed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ringersoft/cdf.ringersoft.com/resources/views/admin/reports/due-status.blade.php ENDPATH**/ ?>