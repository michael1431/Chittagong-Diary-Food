    <div class="col-lg-3">
        <div class="form-group <?php echo e($errors->has('lc') ? 'has-error' : ''); ?> ">
            <?php echo e(Form::label('','L.C No : ')); ?>

            <?php echo e(Form::text('lc',null,['class'=>'form-control','placeholder'=>"Ex. LC1"])); ?>


            <?php if($errors->has('lc')): ?>
                <span class="">
                    <strong><?php echo e($errors->get('chalan_date')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
    </div>


    <div class="col-lg-3">
        <div class="form-group <?php echo e($errors->has('lc_date') ? 'has-error' : ''); ?> ">
            <?php echo e(Form::label('','L.C Date : ')); ?>

            <?php echo e(Form::text('lc_date',null,['class'=>'form-control date','placeholder'=>"Ex. LC1"])); ?>


            <?php if($errors->has('lc_date')): ?>
                <span class="">
                    <strong><?php echo e($errors->get('lc_date')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
    </div>


    <div class="col-lg-3">
        <div class="form-group">
            <?php echo e(Form::label('','Purchase Order  : ')); ?>

            <?php echo e(Form::select('purchase_id',$purchases,false,['class'=>'form-control purchase_id ','placeholder'=>"Select Purchase Order "])); ?>

        </div>
    </div>

    <div class="col-lg-3">
        <div class="form-group <?php echo e($errors->has('chalan') ? 'has-error' : ''); ?> ">

            <?php echo e(Form::label('','Chalan No : ')); ?>

            <?php echo e(Form::text('chalan',null,['class'=>'form-control','placeholder'=>"Ex. 101"])); ?>


            <?php if($errors->has('chalan')): ?>
                <span class="">
                    <strong><?php echo e($errors->get('chalan')); ?></strong>
                </span>
            <?php endif; ?>

        </div>
    </div>

    <div class="col-lg-3">
        <div class="form-group <?php echo e($errors->has('chalan_date') ? 'has-error' : ''); ?> ">
            <?php echo e(Form::label('','Chalan Date : ')); ?>

            <?php echo e(Form::text('chalan_date',null,['class'=>'form-control date','placeholder'=>"Ex. LC1"])); ?>


            <?php if($errors->has('chalan_date')): ?>
                <span class="">
                    <strong><?php echo e($errors->get('chalan_date')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
    </div>


<?php /**PATH /home/ringersoft/cdf.ringersoft.com/resources/views/inventory/goodsin/form-goodsin.blade.php ENDPATH**/ ?>