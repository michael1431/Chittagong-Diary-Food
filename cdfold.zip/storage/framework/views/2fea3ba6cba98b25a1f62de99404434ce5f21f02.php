
<?php $__env->startSection('title','Dues Status  - CDF '); ?>
<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Dues Report </h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Reports</a></li>
                        <li class="breadcrumb-item active">Dues Report </li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->


    <!-- Main content -->
    <section class="content">
        <div class="col-lg-12">
            <div class="row">
                
                <div class="col-lg-12">
                    <div class=" bg-light">
                        <div class="card card-info card-outline">
                            <div class="card-header">
                                <h3 class="card-title">Search Dues Report </h3>
                                <div class="card-tools">
                                    <button type="button" class="btn btn-tool" data-widget="collapse">
                                        <i class="fas fa-plus"></i>
                                    </button>
                                </div>
                            </div> <!-- /.card-header -->

                            <div class="card-body" style="display: block;">
                                <div class="row">

                                    <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">

                                        <?php echo e(Form::open(['route'=>'income_expense.status','method'=>'get','enctype'=>'multipart/form-data','id'=>'report_form'])); ?>


                                        <!--  PRODUCT NAME  -->


                                        <div class="col-lg-3 col-sm-3 col-md-3 col-xs-12" style="float: left;">
                                            
                                            <a href="<?php echo e(route('income_expense.status',['daily=1'])); ?>" class="btn btn-info">Todays Report</a>
                                        </div>
                                        <div class="col-lg-3 col-sm-3 col-md-3 col-xs-12" style="float: left;">
                                            
                                            <a href="<?php echo e(route('income_expense.status',['weekly=1'])); ?>" class="btn btn-info text-light">Last Week's Report</a>
                                        </div>
                                        <div class="col-lg-3 col-sm-3 col-md-3 col-xs-12" style="float: left;">
                                            
                                            <a href="<?php echo e(route('income_expense.status',['monthly=1'])); ?>"
                                                class="btn btn-info ">last Month's Report</a>
                                        </div>

                                        <div class="col-lg-3 col-sm-3 col-md-3 col-xs-12" style="float: left;">
                                            
                                            <div id="demo-dp-range">
                                                
                                                <div class="input-daterange input-group" id="datepicker">
                                                    <?php echo e(Form::text('start',old('start'),['class'=>'form-control','id'=>'start','placeholder'=>'From','required'])); ?>

                                                    <span class="input-group-addon">to</span>
                                                    <?php echo e(Form::text('end',old('end'),['class'=>'form-control','id'=>'end','placeholder'=>'To','required'])); ?>


                                                </div>
                                                <button class="btn btn-info form-control" type="submit"
                                                    id="show_report_customerSupplier">
                                                    Show Report
                                                </button>
                                            </div>
                                        </div>
                                        <!-- / PRODUCT NAME  -->
                                        <?php echo e(Form::close()); ?>

                                    </div>


                                    <div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
                                        <h2 class="text-center">Date-Wise Income Report </h2>
                                        <table class="table table-bordered" id="protable">
                                            <thead>
                                                <tr>
                                                    <th class="text-center">sl</th>
                                                    <th class="text-center">Date</th>
                                                    <th class="text-center">TotalSales</th>
                                                    <th class="text-center">CostOfGoods</th>
                                                    <th class="text-center">GrossProfit</th>
                                                    <th class="text-center">Expenses</th>
                                                    <th class="text-center">NetProfit</th>
                                                </tr>
                                            </thead>
                                            <tbody id="dues_report">
                                                <?php
                                                    $sales_total=0;
                                                    $cogs_total=0;
                                                    $total_exp=0;
                                                    $profit=0;
                                                    $i=0;
                                                ?>
                                                <?php $__empty_1 = true; $__currentLoopData = $dateGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <?php
                                                $purchase_total=0;
                                                $gross_sales=0;
                                                ?>
                                                <tr>
                                                    <td class="text-center"><?php echo e($i+1); ?></td>
                                                    <td class="text-center"><strong><?php echo e($key); ?></strong></td>
                                                    <?php
                                                        if($sales->has($key)){
                                                            foreach($sales[$key] as $sale_detail){
                                                            foreach($sale_detail->product->stocks as $stocks_datails){
                                                            $purchase_rate=$stocks_datails->price;
                                                            }
                                                            $purchase_total+= ($sale_detail->qty * $purchase_rate);
                                                            $gross_sales+=($sale_detail->qty * $sale_detail->price);
                                                            }
                                                        }
                                                    ?>
                                                    <td class="text-right"><?php echo e($gross_sales); ?></td>
                                                    
                                                    <td class="text-right"><?php echo e($purchase_total); ?></td>
                                                    <td class="text-right">
                                                        <?php echo e($balance=$gross_sales - $purchase_total); ?></td>
                                                    <td class="text-right">
                                                        <?php echo e($exp=$expenses->has($key) ? $expenses[$key]->sum('total_paid'): 0); ?>

                                                    </td>
                                                    <?php
                                                    $sales_total+=$gross_sales;
                                                    $cogs_total+=$purchase_total;
                                                    $profit+=($balance-$exp);
                                                    $total_exp+=$exp;
                                                    $i++;
                                                    ?>
                                                    <td class="text-right"><?php echo e($balance-$exp); ?></td>

                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                                <?php endif; ?>
                                            </tbody>
                                            <tfoot>
                                                <tr>
                                                    <th colspan="2" class="text-right">Total</th>
                                                    <th class="text-right" style="border-top:#000 solid 2px;">
                                                        <?php echo e($sales_total); ?></th>
                                                    <th class="text-right" style="border-top:#000 solid 2px;">
                                                        <?php echo e($cogs_total); ?></th>
                                                    <th class="text-right" style="border-top:#000 solid 2px;">
                                                        <?php echo e($sales_total-$cogs_total); ?></th>
                                                    <th class="text-right" style="border-top:#000 solid 2px;">
                                                        <?php echo e($total_exp); ?></th>
                                                    <th class="text-right" style="border-top:#000 solid 2px;">
                                                        <strong><?php echo e($profit); ?></strong></th>
                                                </tr>
                                            </tfoot>

                                        </table>



                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                



            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugin'); ?>
    <!-- DataTables -->
    <script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.js')); ?>"></script>

    <!-- page script -->
    <script type="text/javascript">

        $(document).ready(function(){
            $('#datepicker').datepicker({
                format: 'yyyy-mm-dd'
            });
            $("#protable").DataTable();
            $("#related_party").select2({
                placeholder: 'Select Supllier or Customer'
            });
        });

        $('#type').change(function () {
            var type = $(this).val();

            $.ajax({
                method:"post",
                url:"<?php echo e(route('report.load_parties')); ?>",
                data:{type:type,_token:"<?php echo e(csrf_token()); ?>"},
                success:function (response) {
                    $("#related_party").html(response);
                },
                error:function (err) {
                    console.log(err);
                }
            });
        });


    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fixed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ringersoft/cdf.ringersoft.com/resources/views/admin/reports/income-expense.blade.php ENDPATH**/ ?>