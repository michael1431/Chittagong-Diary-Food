<div class="col-lg-12">
    <div class="form-group">
        <?php echo e(Form::label('','LC No : ')); ?>

        <select name="lc_no" id="lc_no" required>
            <?php $__currentLoopData = $lcs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($lc): ?>
                    <option value="<?php echo e($lc); ?>"><?php echo e($lc); ?></option>
                 <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </select>
        
    </div>
</div>


<div class="col-lg-12">
    <div class="form-group">
        <?php echo e(Form::button($buttonText,['class'=>'btn btn-success getGoodsIn'])); ?>

    </div>
</div><?php /**PATH /home/ringersoft/cdf.ringersoft.com/resources/views/inventory/report/form-lc.blade.php ENDPATH**/ ?>