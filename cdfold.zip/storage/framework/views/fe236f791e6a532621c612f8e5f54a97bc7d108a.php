

<?php $__env->startSection('title','Manage Requisition - Purcahse Requisition'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">

            </div>
        </div><!-- /.container-fluid -->
    </section>
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Quotation taken Requisitions</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Manage Quotation Taken Lists</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>


    <!-- Main content -->
    <section class="content">
        <div class="col-lg-12">

            <div class="card"><br>
                <div class="card-body">
                    <div class="row">
                        
                        <div class="col-lg-12 table-responsive">

                            <table class="table-bordered table-striped table">
                                <thead>
                                    <tr>
                                        <th>#SL</th>
                                        <th>Requisition No</th>
                                        <th>R. Invoice No</th>
                                        <th>Price</th>
                                        <th>Qty</th>
                                        <th>Note</th>
                                        <th>R. Date</th>
                                        <th>Action</th>
                                    </tr>

                                </thead>

                                <tbody>
                                <?php $i=0; ?>
                                <?php if($requisitions->count()>0): ?>
                                    <?php $__currentLoopData = $requisitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$requisition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(++$i); ?></td>
                                            <td width="11%"><?php echo e($requisition->id); ?></td>
                                            <td><?php echo e($requisition->invoice_no); ?></td>
                                            <td><?php echo e($requisition->price); ?></td>
                                            <td><?php echo e($requisition->qty); ?></td>
                                            <td><?php echo e($requisition->note or 'N/A'); ?></td>
                                            <td>
                                                <?php echo e(\Carbon\Carbon::parse($requisition->created_at)->format('D-d-M-Y')); ?>  -- <?php echo e($requisition->created_at->diffForHumans()); ?>

                                            </td>
                                            <td>
                                                <a class=" btn btn-info" href="<?php echo e(route('quotations.list',$requisition->id)); ?>">View Quotation's </a> &nbsp;
                                                    <a class=" btn btn-info" target="_blank" href="<?php echo e(route('quotations.comparative-statement',$requisition->id)); ?>">View Comparative Statement </a>
                                            </td>
                                        </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugin'); ?>
    <!-- DataTables -->
    <script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.js')); ?>"></script>
    <!-- page script -->
    <script type="text/javascript">

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fixed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ringersoft/cdf.ringersoft.com/resources/views/inventory/purchase/requisition-quotation-lists.blade.php ENDPATH**/ ?>