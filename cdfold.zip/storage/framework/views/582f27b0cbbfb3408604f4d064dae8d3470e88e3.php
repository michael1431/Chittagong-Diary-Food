<div class="table-responsive">

    <table class="table table-hover table-striped table-bordered">
        <thead>
            <tr class="bg-info">
                <td> #SL</td>
                <td> Department</td>
                <td> Group</td>
                <td> Code</td>
                <td> Name</td>
                <td> Unit</td>
                <td> Price</td>
                <td> Cur Stock</td>
                <td> 2 Months Consum.</td>
                <td> Qty</td>
                <td> Last Purchase </td>
                <td> Remarks</td>
                <td> Action </td>
            </tr>
        </thead>

        <tbody class="bodyItem" id="requisition_items">
            <tr>
                <td colspan="12" class=" bg-danger text-center"> No Requisition Product found</td>
            </tr>
        </tbody>
    </table>

    <br>
    <br>
    <br>

</div>


<?php /**PATH /home/ringersoft/cdf.ringersoft.com/resources/views/inventory/requisition/item-list-requisition.blade.php ENDPATH**/ ?>