

<?php $__env->startSection('title','Manage Order -CDF'); ?>
<?php $__env->startSection('style'); ?>
    <style>
        .check_label{
            padding: 5px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">

            </div>
        </div><!-- /.container-fluid -->
    </section>
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>All Order</h1>
                <p>
                    <?php if(request('order_history')): ?>
                    <a class="btn btn-xs btn-info" href="<?php echo e(route('view-order')); ?>">View Pending Order</a>
                    <?php else: ?>
                    <a class="btn btn-xs btn-info" href="<?php echo e(route('view-order',['order_history=1'])); ?>">View Order History</a>
                    <?php endif; ?>
                </p>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Order List</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>


    <!-- Main content -->
    <div class="row">
        <div class="container-fluid">
        
        <!-- Main content -->
        <section class="content">
            <div class="col-lg-12">
    
                <div class="card"><br>
                    <div class="card-body">
                        <div class="row">
    
                            
                            <div class="col-lg-12 table-responsive">
                                <h4 class="bg-info text-center" style="padding: 10px;">List of Order Item's</h4>
                                <div class="table-responsive">
    
                                    <table class="table table-hover table-striped table-bordered">
                                        <thead>
                                            <tr class="bg-info">
                                                <td> #SL</td>
                                                <td> Code</td>
                                                <td> Name</td>
                                                <td> Price</td>
                                                <td> Qty</td>
                                                <td> Remarks</td>
                                                <td> Action </td>
                                            </tr>
                                        </thead>
                                
                                        <tbody class="bodyItem" id="requisition_items">
                                            <tr>
                                                <td colspan="12" class=" bg-danger text-center">Product yet not ordered ! !! !!!</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                
                                    <br>
                                    <br>
                                    <br>
                                
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-4 form-group">
                                        <?php echo e(Form::label('','Sub-Distributor')); ?>

                                        <?php echo e(Form::text('distributor[name]',null,['class'=>'form-control','id'=>"distributor_name"])); ?>

                                    </div>
                                    <div class="col-md-4 form-group">
                                        <?php echo e(Form::label('','Sub-Distributor Phone')); ?>

                                        <?php echo e(Form::text('distributor[phone]',null,['class'=>'form-control','id'=>"distributor_phone"])); ?>

                                    </div>
                                    <div class="col-md-4 form-group">
                                        <?php echo e(Form::label('','Sub-Distributor Address')); ?>

                                        <?php echo e(Form::text('distributor[address]',null,['class'=>'form-control','id'=>"distributor_address"])); ?>

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4 form-group">
                                        <?php echo e(Form::label('','Customer')); ?>

                                        <select name="customer_name" id="customer_name">
                                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($customer->user_id): ?>
                                                    <option value="<?php echo e($customer->user_id); ?>"><?php echo e($customer->name." ".$customer->phone1); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        
                                    </div>
                                    <div class="col-md-6 form-group">
                                        <?php echo e(Form::label('','Note / Description')); ?>

                                        <?php echo e(Form::text('description',null,['class'=>'form-control confirmationNote','placeholder'=>'Order note '])); ?>

                                    </div>
                                    <div class="col-md-2 form-group">
                                        <?php echo e(Form::label('','')); ?>

                                        <?php echo e(Form::button("Confirm Order",['class'=>'form-control btn btn-info btn-block confirmRequisition','style'=>'margin-top:6px;'])); ?>

                                    </div>
                                </div>
                               
                                
                                <br>
                                <br>
                            </div>
                            
    
                            
                            <div class="col-lg-12 table-responsive">
                                <h4 class="bg-info text-center" style="padding: 10px;">Item Add Form</h4>
                                <div class="row">
                                    <div class="col-lg-6 col-sm-6">
                                        <div class="form-group<?php echo e($errors->has('code') ? ' has-error' : ''); ?>">
                                            <?php echo e(Form::label('', 'Item Code', ['class'=>'label-control'])); ?>

                            
                                          
                            
                                            
                            
                                            <select onchange="get_product_price()" class="form-control" id="product_id">
                                                <option>Select Code/Name</option>        
                                                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                        <option value="<?php echo e($product->id); ?>"> <label class="label-success"> <?php echo e($product->item_code); ?> </label> - <?php echo e($product->name); ?> - <?php echo e($product->department ? $product->department->name : " "); ?> - <?php echo e($product->group ? $product->group->name : " "); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <?php endif; ?>
                                  
                                            </select>
                                            <?php if($errors->has('code')): ?>
                                                <span class="help-block text-center" id="success-alert">
                                                <strong><?php echo e($errors->first('code')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                            
                            
                            
                                    <div class="col-lg-2 col-sm-2">
                                        <div class="form-group<?php echo e($errors->has('product_unit_id') ? ' has-error' : ''); ?>">
                                            <?php echo e(Form::label('', 'Unit', ['class'=>'label-control'])); ?>

                                            <?php echo e(Form::text('product_unit_id',null,['class'=>'form-control','autofocus','readonly','id'=>'unit'])); ?>

                            
                                            <?php if($errors->has('product_unit_id')): ?>
                                                <span class="help-block text-center" id="success-alert">
                                                <strong><?php echo e($errors->first('product_unit_id')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                            
                                    <div class="col-lg-2 col-sm-2">
                                        <div class="form-group<?php echo e($errors->has('qty') ? ' has-error' : ''); ?>">
                                            <?php echo e(Form::label('', 'Qty', ['class'=>'label-control'])); ?>

                                            <?php echo e(Form::text('qty',null,['class'=>'form-control','autofocus','required','placeholder'=>'Ex. 50','autocomplete'=>"off",'id'=>'qty'    ])); ?>

                            
                                            <?php if($errors->has('qty')): ?>
                                                <span class="help-block text-center" id="success-alert">
                                            <strong><?php echo e($errors->first('qty')); ?></strong>
                                        </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                            
                            
                                    <div class="col-lg-2 col-sm-2">
                                        <div class="form-group<?php echo e($errors->has('price') ? ' has-error' : ''); ?>">
                                            <?php echo e(Form::label('', 'Price', ['class'=>'label-control'])); ?>

                                            <?php echo e(Form::text('price',null,['class'=>'form-control','autofocus','required','placeholder'=>'Ex. 120 tk','id'=>'price'])); ?>

                            
                                            <?php if($errors->has('price')): ?>
                                                <span class="help-block text-center" id="success-alert">
                                                <strong><?php echo e($errors->first('price')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                            
                            
                                    <div class="col-lg-12 col-sm-12">
                                        <div class="form-group<?php echo e($errors->has('price') ? ' has-error' : ''); ?>">
                                            <?php echo e(Form::label('', 'Note / Remarks / Description ', ['class'=>'label-control'])); ?>

                                            <?php echo e(Form::textarea('note',null,['class'=>'form-control','autofocus','rows'=>5,'cols'=>5,'placeholder'=>'Ex. Remarks / Note / Description','id'=>'note'])); ?>

                            
                                            <?php if($errors->has('price')): ?>
                                                <span class="help-block text-center" id="success-alert">
                                                    <strong><?php echo e($errors->first('price')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                            
                                    <div class=" col-lg-3">
                                        <div class="form-group">
                                            <?php echo e(Form::button("Add To Order List",['class'=>'btn btn-primary btn-block storeRequestRequisition'])); ?>

                                        </div>
                                    </div>
                            </div>
                            
    
                            </div>
                            
    
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- /.content -->
        </div>
    </div>
    <script src="<?php echo e(asset('plugins/jquery/jquery.min.js')); ?>"></script>
    <script>
         $(document).ready(function () {
                pendingProducts();
            });
    
            /* pending product list start */
            function pendingProducts() {
              //alert();
                $.ajax({
                    method:"get",
                    url:"<?php echo e(route('inventory.requisition.pending.products',['sales_man_order=1'])); ?>",
                    dataType:"html",
                    success:function (response) {
                        $("#requisition_items").html(response);
                    }
                });
            }
             /* store requisition at TempData Start*/
            $(document).on('click','.storeRequestRequisition',function () {
                var product_id = $("#product_id").val();
                var price = $("#price").val();
                var qty = $('#qty').val();
                var note = $("#note").val();
    
                if(product_id =="Select Code/Name" || price =='' || qty ==''){
                    $("#qty").css({"background":"#DC4C40","color":"#fff"});
                    $("#price").css({"background":"#DC4C40","color":"#fff"});
                }else{
                    $.ajax({
                        method:"post",
                        url:"<?php echo e(route('inventory.purchase.temp.store')); ?>",
                        data : {product_id:product_id,price:price,qty:qty,type:5,note:note, _token:"<?php echo e(csrf_token()); ?>"},
                        dataType:"json",
                        success:function (res) {
                            pendingProducts();
                            if(res.success == 1){
                                $.notify("Product / Item Added to Order List", {globalPosition: 'bottom center',className: 'success'});
                            }
                            $("#unit").val(null);
                            $("#price").val(null);
                            $('#qty').val(null);
                            $('#note').val(null);
                        }
                    });
                }
            });
            // /* store requisition at TempData End */
    
          function get_product_price(){
              var id = $("#product_id").val();
              if(id !=null){
                  $.ajax({
                      method:"post",
                      url:"<?php echo e(route('inventory.item.info')); ?>",
                      data: {id:id, _token:"<?php echo e(csrf_token()); ?>"},
                      dataType:'json',
                      success:function (response) {
                          //$("#unit").val(response.unit);
                          $("#price").val(response.price);
                      }
                  });
              }
          }
            /* Requisition Confirmation Start */
            $(document).on("click",".confirmRequisition",function () {
               var note = $('.confirmationNote').val();
               var customer = $('#customer_name').val();
               var distributor_name = $('#distributor_name').val();
               var distributor_phone = $('#distributor_phone').val();
               var distributor_address = $('#distributor_address').val();
                
                var token  = "<?php echo e(csrf_token()); ?>";
                $.ajax({
                    method:"post",
                    url : "<?php echo e(route('store-daily-log')); ?>",
                    data:{ note:note, _token:token,customer:customer,name:distributor_name,phone:distributor_phone,address:distributor_address},
                    dataType:"json",
                    success:function (res) {
                        if (res.success == 1){
                            pendingProducts();
                            $.notify("Order Created successfully", {globalPosition: 'bottom center',className: 'success'});
                            $('.confirmationNote').val(null);
                        }
                    }
                });
    
            });
    </script>
    

<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugin'); ?>
    <!-- DataTables -->
    <script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.js')); ?>"></script>

    <!-- page script -->
    <script type="text/javascript">

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fixed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ringersoft/cdf.ringersoft.com/resources/views/inventory/sales_order/custom-order.blade.php ENDPATH**/ ?>