

<?php $__env->startSection('title','Manage Order -CDF'); ?>
<?php $__env->startSection('style'); ?>
    <style>
        .check_label{
            padding: 5px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">

            </div>
        </div><!-- /.container-fluid -->
    </section>
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>All Order </h1>
                    
                <p>
                    <?php if(request('order_history')): ?>
                    <a class="btn btn-xs btn-info" href="<?php echo e(route('view-order')); ?>">View Pending Order</a>
                    <?php else: ?>
                    <a class="btn btn-xs btn-info" href="<?php echo e(route('view-order',['order_history=1'])); ?>">View Order History</a>
                    <?php endif; ?>
                    
                </p>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Order List</li>
                    </ol>
                   
                </div>
                
            </div>
        </div><!-- /.container-fluid -->
    </section>


    <!-- Main content -->
    <section class="content">
        <div class="col-lg-12">

            <div class="card"><br>
                <div class="card-body">
                    <div class="row">
                        
                        <div class="col-lg-12 table-responsive">
                        <center><caption><h2>Order List</h2></caption></center>
                            <table class="table-bordered table-striped table">
                                <thead>
                                    <th>#SL</th>
                                    <th>Order No</th>
                                    <th>Total Amount</th>
                                    <th>OrderBy</th>
                                    <?php if(request('order_history')): ?>
                                    <th>SoldBy</th>
                                    <?php endif; ?>
                                    <th>Status</th>
                                    <th>Order Date</th>
                                    <th>Action</th>
                                </thead>

                                <tbody>
                                    <?php $i=0; ?>
                                    <?php if($invoices->count()>0): ?>
                                        <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e(++$i); ?></td>
                                                <td width="11%"><?php echo e($invoice->invoice_no); ?></td>
                                                <td><?php echo e($invoice->total_amount); ?></td>
                                                <td><?php echo e($invoice->related_party_type=='Customer' ? $invoice->order_by->name : ''); ?></td>
                                                <?php if(request('order_history')): ?>
                                                    <td><?php echo e($invoice->user->name); ?></td>
                                                <?php endif; ?>
                                                <td>
                                                    <?php if($invoice->status==0): ?>
                                                        <label class='label label-danger check_label'>Pending</label> 
                                                    <?php else: ?> 
                                                    <a href="<?php echo e(route('invoice.print',[$invoice->id,'chalan'=>1])); ?>">
                                                        <label class='label label-success check_label'> Delivered </label>
                                                    <?php endif; ?>
                                                </td>
                                                <td> 
                                                    <?php echo e(\Carbon\Carbon::parse($invoice->created_at)->format('D-d-M-Y')); ?>  -- <?php echo e($invoice->created_at->diffForHumans()); ?>

                                                </td>
                                                <td>
                                                    <a class=" <?php echo e($invoice->status ==0 ? "fa fa-eye btn btn-danger" : "fa fa-eye  btn btn-success"); ?>" href="<?php echo e($invoice->status ==0 ? route('invoice-show',$invoice->id) : route('invoice.print',$invoice->id)); ?>"></a>
                                                    <?php if($invoice->status): ?>
                                                        <a class="far fa-minus-circle btn btn-info" href="<?php echo e(route('invoice-return',$invoice->id)); ?>"></a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                            <?php echo e($invoices->appends(request()->input())->render()); ?>

                        </div>
                        

                    </div>
                </div>
            </div>
        </div>
    </section>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugin'); ?>
    <!-- DataTables -->
    <script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.js')); ?>"></script>

    <!-- page script -->
    <script type="text/javascript">

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fixed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ringersoft/cdf.ringersoft.com/resources/views/inventory/sales_order/pending-order.blade.php ENDPATH**/ ?>