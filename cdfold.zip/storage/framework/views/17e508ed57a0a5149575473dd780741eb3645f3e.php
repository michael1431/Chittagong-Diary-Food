<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- Bootstrap CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/fontawesome-free-5.6.3-web/css/all.min.css')); ?>">
    <!-- Nano Scroller -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/nanoScroller/nanoscroller.css')); ?>">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">

    <!-- daterange picker -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/daterangepicker/daterangepicker-bs3.css')); ?>">
    <!-- date picker -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/datepicker/datepicker3.css')); ?>" />
    <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.css">
    <?php echo $__env->yieldContent('plugin-css'); ?>

<!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('dist/css/adminlte.min.css?ver:2.0')); ?>">

    <!-- Theme style -->
    <link rel="stylesheet" href="<?php echo e(asset('dist/css/ahmed-style.min.css')); ?>">

    <!-- Google Font: Source Sans Pro -->
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.png')); ?>">
    <!-- Select2 -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/select2/select2.min.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('css/sweetalert.css')); ?>">

    <link href="https://fonts.maateen.me/adorsho-lipi/font.css" rel="stylesheet">

    
    

    <style>
        @media  print {
            .thead-dark {
                background-color: gray;
            }

            .row-cccccc {
                background-color: #cccccc;
            }

            .row-dddddd {
                background-color: #dddddd;
            }
        }


    </style>
    
    <link rel="stylesheet" href="<?php echo e(asset('css/print.css')); ?>">

    <link rel="shortcut icon" href="<?php echo e(asset('favicon.ico')); ?>">

    <style>
        span.select2-selection.select2-selection--single{ padding-bottom: 29px; border-color: #cccccc;}
        input.select2-search__field{ border-color: #cccccc;
            -webkit-border-radius:5px;
            -moz-border-radius:5px;
            border-radius:5px;
        }

        span.select2-selection__arrow {  margin-top: 4px;  }
        a,h1,h2,h3,h4,h5,h6,span,p,strong,select,b,i,input,textarea,li,label,td,th,button,radio,checkbox,div{
          /*  text-transform: uppercase; */
        }
        .select2{
            width: 100%!important;
        }
        .loanTable th {
            font-size: 13px;
        }
        .loanTable td {
            font-size: 15px;
            text-align: left;
            font-weight: 400;
        }
    </style>
    <?php echo $__env->yieldContent('style'); ?>
    <?php echo $__env->yieldContent('css'); ?>

</head>

<body class="hold-transition sidebar-mini">

<div class="wrapper" id="app">
    <!-- Navbar -->
    
    <nav class="main-header navbar navbar-expand border-bottom navbar-dark bg-info">
        <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </nav>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <aside class="main-sidebar sidebar-dark-info elevation-4">
    <?php echo $__env->make('includes.left-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /.sidebar -->
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <!-- /.content-wrapper -->
    <footer class="main-footer">
        <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </footer>
    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
        <?php echo $__env->make('includes.right-aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </aside>
    <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->


<script>
    // data = {
    //     'name':'Ahmed Sohel',
    //     'email':'ahmed@gmail.com',
    //     'phone':'0906565556565'
    // };

    // console.table(data);
</script>

<!-- jQuery -->
<script src="<?php echo e(asset('plugins/jquery/jquery.min.js')); ?>"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo e(asset('plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<!-- Nano Scroller -->
<script src="<?php echo e(asset('plugins/nanoScroller/jquery.nanoscroller.min.js')); ?>"></script>
<!-- AdminLTE App -->


<script src="<?php echo e(asset('dist/js/adminlte.js')); ?>"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo e(asset('dist/js/demo.js')); ?>"></script>

<!-- date-range-picker -->
<script src="https://rawgit.com/moment/moment/2.2.1/min/moment.min.js"></script>

<script src="<?php echo e(asset('plugins/daterangepicker/daterangepicker.js')); ?>"></script>

<script src="<?php echo e(asset('plugins/datepicker/bootstrap-datepicker.js')); ?>"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.js"></script>
<!-- Select2 -->
<script src="<?php echo e(asset('plugins/select2/select2.min.js')); ?>"></script>

<script src="<?php echo e(asset('plugins/select2/select2.full.min.js')); ?>/"></script>


<script src="<?php echo e(asset('js/sweetalert.min.js')); ?>"></script>

<script src="<?php echo e(asset('js/notify.js')); ?>"></script>





<script src="<?php echo e(asset('js/hilitor.js')); ?>"></script>
<script src="<?php echo e(asset('js/custom.js')); ?>"></script>

<?php echo $__env->yieldContent('plugin'); ?>
<?php echo $__env->yieldContent('script'); ?>


<script>

    /** CHECK EVERY ACTION DELETE CONFIRMATION BY SWEET ALERT **/
    $(document).on('click', '.erase', function () {
        var id = $(this).attr('data-id');
        var url=$(this).attr('data-url');
        var token = '<?php echo e(csrf_token()); ?>';
        var $tr = $(this).closest('tr');
        swal({
                title: "Are you sure?",
                text: "You will not be able to recover this information!",
                type: "warning",
                showCancelButton: true,
                confirmButtonClass: 'btn-danger',
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: "No, cancel plz!",
                closeOnConfirm: false,
                closeOnCancel: false
            },
            function (isConfirm) {
                if (isConfirm) {
                    $.ajax({
                        url: url,
                        type: "post",
                        data: {id: id, _token: token},
                        dateType:'html',
                        success: function (response) {
                            swal("Deleted!", "Data has been Deleted.", "success"),
                                swal({
                                        title: "Deleted!",
                                        text: "Data has been Deleted.",
                                        type: "success"
                                    },
                                    function (isConfirm) {
                                        if (isConfirm) {
                                            $tr.find('td').fadeOut(1000, function () {
                                                $tr.remove();
                                            });
                                        }
                                    });
                        }
                    });
                } else {
                    swal("Cancelled", "Your data is safe :)", "error");
                }
            });
    });
</script>


<script>
    $(function () {
        $('.dataTable').dataTable();

        $('[data-toggle="tooltip"]').tooltip()
    })
</script>

<?php if(session()->has('success')): ?>
    <script type="text/javascript">
        $(function () {
            $.notify("<?php echo e(session()->get("success")); ?>", {globalPosition: 'top center',className: 'success'});
        });
    </script>
<?php endif; ?>

<?php if(session()->has('message')): ?>
    <script type="text/javascript">
        $(function () {
            $.notify("<?php echo e(session()->get("success")); ?>", {globalPosition: 'bottom right',className: 'message'});
        });
    </script>
<?php endif; ?>

<?php if(session()->has('error')): ?>
    <script type="text/javascript">
        $(function () {
            $.notify("<?php echo e(session()->get("error")); ?>", {globalPosition: 'bottom right',className: 'error'});
        });
    </script>
<?php endif; ?>

<?php if(session()->has('warning')): ?>
    <script type="text/javascript">
        $(function () {
            $.notify("<?php echo e(session()->get("warning")); ?>", {globalPosition: 'bottom right',className: 'warn'});
        });
    </script>
<?php endif; ?>

<script>
    $(document).ready(function () {

        $("select").select2();
//       var d = new Date();
//       var day = 0;
//       if (d.getDate().length<2){
//           day = 0+d.getDate();
//       }else{
//           day = d.getDate();
//       }
//
//       var custom_date = d.getFullYear()+"-"+d.getMonth()+"-"+day;
//       $(".join_date").val(custom_date);
        $('.date-picker').datepicker();
        $('.date').datepicker({
            'format':'yyyy-mm-dd'
        });
    });



</script>
</body>
</html>
<?php /**PATH /home/ringersoft/cdf.ringersoft.com/resources/views/layouts/fixed.blade.php ENDPATH**/ ?>