<?php echo e(Form::label('', 'Warehouse Name ', ['class'=>'label-control'])); ?>


<div class="form-group<?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
    <?php echo e(Form::text('name',null,['class'=>'form-control','placeholder'=>'Ex. Ghudam 1'])); ?>



    <?php if($errors->has('name')): ?>
        <p class="text-danger" id="success-alert">
            <?php echo e($errors->first('name')); ?>

        </p>
    <?php endif; ?>

</div>


<div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
    <?php echo e(Form::label('description', 'Description', ['class'=>'label-control'])); ?>

    <?php echo e(Form::textarea('description',old('description'),['class'=>'form-control','placeholder'=>'','rows'=>5,'cols'=>5])); ?>


    <?php if($errors->has('description')): ?>
        <span class="text-danger">
            <p> <?php echo e($errors->first('description')); ?> </p>
        </span>
    <?php endif; ?>
</div>

<div class="form-group row text-right">
    <div class="col-md-12">
        <a href="<?php echo e(URL::previous()); ?>">
            <button  class="btn btn-sm btn-danger">Back</button>
        </a>
        <button type="submit" class="btn btn-sm btn-success"><?php echo e($buttonText); ?></button>
        <input type="reset" value="Reset" class="btn btn-sm btn-warning">
    </div>
</div>
<?php /**PATH /home/ringersoft/cdf.ringersoft.com/resources/views/inventory/warehouse/form-warehouse.blade.php ENDPATH**/ ?>