<div class="table-responsive">
    <table class="table table-hover" id="ProunitTable">
        <thead>
            <tr>
                <td> #SL</td>
                <td> Name</td>
                <td> Description</td>
                <td> Action</td>
            </tr>
        </thead>

        <tbody>
            <?php $i=0; ?>
            <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e(++$i); ?></td>
                    <td> <?php echo e($unit->name); ?></td>
                    <td> <?php echo e($unit->description); ?></td>
                    <td>
                        <a href="<?php echo e(route('inventory.unit.edit',$unit->id)); ?>" class="btn btn-edit btn-success far fa-edit"></a>
                        <?php echo e(Form::button('',['class'=>'btn btn-danger fas fa-trash-alt erase','data-id'=>$unit->id,'data-url'=>route('inventory.unit.destroy')])); ?>


                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>
</div><?php /**PATH /home/ringersoft/cdf.ringersoft.com/resources/views/inventory/unit/units-inventory.blade.php ENDPATH**/ ?>