
<?php $__env->startSection('title','Sales Details  - CDF '); ?>
<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Order Details</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Sales</a></li>
                        <li class="breadcrumb-item active">Order Details</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->


    <!-- Main content -->
    <section class="content">
        <div class="col-lg-12">
            <div class="row">
                
                <div class="col-lg-12">
                    <div class=" bg-light">
                        <div class="card card-info card-outline">
                            <div class="card-header">
                            <h3 class="card-title">Invoice No: <?php echo e($invoice->invoice_no); ?></h3>
                                
                                <div class="card-tools">
                                    <button type="button" class="btn btn-tool" data-widget="collapse">
                                        <i class="fas fa-plus"></i>
                                    </button>
                                </div>
                            </div> <!-- /.card-header -->

                            <div class="card-body" style="display: block;">
                              
                                <div class="row">
                                    <hr>

                                    <div class="col-lg-12">
                                        <h6 class="text-center bg-primary" style="padding:5px 0;font-size: 1.5rem;font-weight: bold;letter-spacing: 10px">Product List</h6>
                                        <hr>
                                          <?php echo e(Form::open(['route'=>'sales.store','method'=>'post', 'class'=>'form-horizontal'])); ?>

                                    <input type="hidden" name="invoice_id" value="<?php echo e($invoice->id); ?>">
                                        <table class="table-hover table-bordered  table goodsinProList">
                                            <thead>
                                                <tr>
                                                    <th rowspan="2" class="text-center">SL</th>
                                                    <th rowspan="2" class="text-center">Item</th>
                                                    
                                                    <th rowspan="2" class="text-center">inStockQty</th>
                                                    <th rowspan="2" class="text-center">OrderedQTY</th>
                                                    <th rowspan="2" class="text-center">QTY</th>
                                                    <th rowspan="2" class="text-center">Price</th>                                                    
                                                    <th colspan="2" class="text-center">Commission</th>
                                                </tr>
                                                <tr>   
                                                     <th class="text-center"><label class="checkbox-inline"><input type="checkbox" value="mar" id="market" onclick="show_amount(2)"> Marketing</label></th>
                                                    <th class="text-center"><label class="checkbox-inline"><input type="checkbox" value="emp" id="employee" onclick="show_amount(1)"> Employee</label></th>
                                                
                                                </tr>
                                            </thead>

                                            <tbody class="proList">
                                                <?php $__empty_1 = true; $__currentLoopData = $sales_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr>
                                                        <td><?php echo e($key+1); ?></td>
                                                        <td><?php echo e($sale->product->name); ?></td>
                                                        <td class="text-right"> <?php echo e($sale->product->stocks->sum('qty') -$sale->product->stocks->sum('stock_out_qty')); ?> </td>
                                                        <td class="text-right"> <?php echo e($sale->qty); ?> </td>
                                                        <td class="text-right">
                                                            <div class="form-group"> <input class="form-control-sm" type="number" value="<?php echo e($sale->qty); ?>" name="qty[<?php echo e($sale->id); ?>]" min="1" max="<?php echo e($sale->product->stocks->sum('qty') -$sale->product->stocks->sum('stock_out_qty')); ?>"></div>
                                                        </td>
                                                        <td class="text-right"> <?php echo e($sale->price); ?> </td>
                                                        <td>
                                                            <div class="form-group"> <input class="form-control-sm mar_commission" type="number" value="0" data-marcommission="<?php echo e($sale->product->marketing_commission); ?>" step=".01" name="mar_commission[<?php echo e($sale->id); ?>]"></div>
                                                            
                                                        </td>
                                                        <td><div class="form-group">  <input class="form-control-sm emp_commission" size="3" type="number" value="0" data-empcommission="<?php echo e($sale->product->employee_commission); ?>"  step=".01" name="emp_commission[<?php echo e($sale->id); ?>]"> </div></td>
                                                       
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <tr>
                                                    <td colspan="7" class="text-center bg-danger">No Product Information Found</td>
                                                </tr>
                                                <?php endif; ?>
                                            </tbody>

                                        </table>
                                    </div>

                                    <div class="col-lg-9"></div>


                                    <div class=" col-lg-offset-9  col-lg-4">
                                        <div class="form-group">
                                            <?php echo e(Form::label('','Confirm Order : ')); ?>

                                            <?php echo e(Form::textarea('note',null,['class'=>'form-control','placeholder'=>'Ex. Goods in Note ','rows'=>5,'cols'=>5  ])); ?>

                                        </div>
                                    </div>


                                    <div class="col-lg-8"></div>

                                    <div class="col-lg-4">
                                        <div class="form-group">
                                            <?php echo e(Form::submit('Confirm Order',['class'=>'form-control btn btn-info'])); ?>

                                        </div>
                                    </div>
                                </div>
                                <?php echo e(Form::close()); ?>

                            </div>
                        </div>
                    </div>
                </div>
                



            </div>
        </div>
        <script>
        function show_amount(type){
            if(type==2){
               var cks=$("#market").is(':checked');
                $(".mar_commission").each(function(){
                    //console.log($(this).attr("data-marcommission"));
                    $(this).val(cks ? $(this).attr("data-marcommission") : 0);
                });
            }
            if(type==1){
                var cks=$("#employee").is(':checked');
                $(".emp_commission").each(function(){
                    //console.log($(this).attr("data-empcommission"));
                    $(this).val(cks ?$(this).attr("data-empcommission") : 0);
                });
            }
        }
        </script>
    </section><!-- /.content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugin'); ?>
    <!-- DataTables -->
    <script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- page script -->
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.fixed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ringersoft/cdf.ringersoft.com/resources/views/inventory/sales_order/order_details.blade.php ENDPATH**/ ?>