
<?php $__env->startSection('title','ExpenseManagement   - CDF '); ?>
<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Manage  Expense </h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Settings</a></li>
                        <li class="breadcrumb-item active">Manage Expense</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->


    <!-- Main content -->
    <section class="content">
        <div class="col-lg-12">
            <div class="row">
                
                <div class="col-lg-12">
                    <div class=" bg-light">
                        <div class="card card-info card-outline">
                            <div class="card-header">
                                <h3 class="card-title">Add Expense </h3>
                                <div class="card-tools">
                                    <button type="button" class="btn btn-tool" data-widget="collapse">
                                        <i class="fas fa-plus"></i>
                                    </button>
                                </div>
                            </div> <!-- /.card-header -->

                            <div class="card-body" style="display: block;">
                                <div class="row">
                                    <div class="col-lg-3">
                                        <?php echo e(Form::open(['route'=>'lccost.store','method'=>'post', 'class'=>'form-horizontal'])); ?>

                                        
                                        <div class="row">
                                            <div class="col-lg-12">
                                                <div class="form-group">
                                                    <?php echo e(Form::label('','ExpenseType : ')); ?>

                                                   <select name="expense_type" onchange="qtyToggle()" id="expense_type">
                                                       <option value="1">Daily Office Expense</option>
                                                       <option value="2">Purchase Gift or Stationary</option>
                                                       <option value="3">LC wise Cost</option>
                                                       <option value="4">Salary</option>
                                                   </select>
                                                </div>
                                            </div>

                                            <div class="col-lg-12" id="lc_cost_option" style="display:none">
                                                <div class="form-group">
                                                    <?php echo e(Form::label('','L.C No : ')); ?>

                                                    <select name="lc_no" id="lc_no" class="lc_cost">
                                                        <option value="">Select LC No</option>
                                                        <?php $__empty_1 = true; $__currentLoopData = $lcs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                            <?php if($lc): ?>
                                                                <option value="<?php echo e($lc); ?>"><?php echo e($lc); ?></option>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                        <?php endif; ?>
                                                        
                                                    </select>
                                                </div>
                                            </div>
                                        
                                        
                                            <div class="col-lg-12">
                                                <div class="form-group <?php echo e($errors->has('cost_id') ? 'has-error' : ''); ?> ">
                                                    <?php echo e(Form::label('','Cost Type : ')); ?>

                                                    
                                                <select name="cost_id" id="cost_id" class="form-control" required>
                                                    <option value="">Select Cost Type</option>
                                                    <?php $__empty_1 = true; $__currentLoopData = $costs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$cost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                        <?php if($cost): ?>
                                                            <option value="<?php echo e($key); ?>"><?php echo e($cost); ?></option>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <?php endif; ?>
                                                    <?php if($errors->has('cost_id')): ?>
                                                        <span class="">
                                                            <strong><?php echo e($errors->get('cost_id')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </select>
                                                </div>
                                            </div>

                                        <div id="qty_option" style="display:none" class="col-lg-12">
                                                <div class="col-lg-12">
                                                    <div class="form-group <?php echo e($errors->has('product') ? 'has-error' : ''); ?> ">
                                                        <?php echo e(Form::label('','Product : ')); ?>

                                                        <select name="product" id="product" class="form-control" required>
                                                            <option value="null">Select Product</option>
                                                            <?php $__empty_1 = true; $__currentLoopData = $giftProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                                <?php if($product): ?>
                                                                    <option value="<?php echo e($key); ?>"><?php echo e($product); ?></option>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                            <?php endif; ?>
                                                            <?php if($errors->has('product')): ?>
                                                                <span class="">
                                                                    <strong><?php echo e($errors->get('product')); ?></strong>
                                                                </span>
                                                            <?php endif; ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            <div class="col-lg-12">
                                                <div class="form-group <?php echo e($errors->has('qty') ? 'has-error' : ''); ?> ">
                                                    <?php echo e(Form::label('','Qty : ')); ?>

                                                    <?php echo e(Form::number('qty',0,['id'=>'qty','onchange'=>'sumUp()','class'=>'form-control','placeholder'=>"Ex. 500 tk"])); ?>

                                        
                                                    <?php if($errors->has('qty')): ?>
                                                        <span class="">
                                                            <strong><?php echo e($errors->get('qty')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-lg-12">
                                                <div class="form-group <?php echo e($errors->has('price') ? 'has-error' : ''); ?> ">
                                                    <?php echo e(Form::label('','Price : ')); ?>

                                                    <?php echo e(Form::number('price',0,['id'=>'price','onchange'=>'sumUp()','class'=>'form-control','placeholder'=>"Ex. 500 tk"])); ?>

                                        
                                                    <?php if($errors->has('price')): ?>
                                                        <span class="">
                                                            <strong><?php echo e($errors->get('price')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                            <div class="col-lg-12">
                                                <div class="form-group <?php echo e($errors->has('amount') ? 'has-error' : ''); ?> ">
                                                    <?php echo e(Form::label('','Cost Amount : ')); ?>

                                                    <?php echo e(Form::number('amount',null,['id'=>'amount','class'=>'form-control','placeholder'=>"Ex. 500 tk"])); ?>



                                                    <?php if($errors->has('amount')): ?>
                                                        <span class="">
                                                            <strong><?php echo e($errors->get('amount')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        
                                        
                                            <div class="col-lg-12">
                                                <div class="form-group <?php echo e($errors->has('note') ? 'has-error' : ''); ?> ">
                                                    <?php echo e(Form::label('','Cost Note : ')); ?>

                                                    <?php echo e(Form::textarea('note',null,['class'=>'form-control','placeholder'=>"Ex. Cost Note",'cols'=>5,'rows'=>5])); ?>

                                        
                                                    <?php if($errors->has('note')): ?>
                                                        <span class="">
                                                            <strong><?php echo e($errors->get('note')); ?></strong>
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        
                                        
                                            <div class="col-lg-12">
                                                <div class="form-group <?php echo e($errors->has('amount') ? 'has-error' : ''); ?> ">
                                                    <?php echo e(Form::submit('Submit Expenses',['class'=>'form-control btn btn-success'])); ?>

                                                </div>
                                            </div>
                                        
                                        
                                        </div>

                                        <?php echo e(Form::close()); ?>

                                    </div>

                                    
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                



            </div>
        </div>
    </section><!-- /.content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugin'); ?>
    <!-- DataTables -->
    <script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- page script -->
    <script type="text/javascript">
        $(document).ready(function () {
            window.setTimeout(function() {
                $(".alert").fadeOut(500, function(){
                    $(this).remove();
                });
            }, 1200);

        });

        function qtyToggle() {
           var type= document.getElementById("expense_type").value;
           //alert(type);
            if(type=='2'){
                document.getElementById("qty_option").style.display ='block';
                document.getElementById("lc_cost_option").style.display ='none';
                $("#amount").attr('readonly',true);

            }else if(type=='3'){
                document.getElementById("qty_option").style.display ='none';
                document.getElementById("lc_cost_option").style.display ='block';
                $("#amount").attr('readonly',false);
                $(".lc_cost").select2({
                    tags: true
                });
            }else{
                document.getElementById("qty_option").style.display ='none';
                document.getElementById("lc_cost_option").style.display ='none';
                $("#amount").attr('readonly',false);
            }     
        }
        //delete confirmation  message
        function confirmDelete(){
            var x = confirm('Are you sure you want to delete this ?');
            return !!x;
        }
        function sumUp(){
            var q = document.getElementById("qty").value;
            var p = document.getElementById("price").value;
            document.getElementById("amount").value=(p*q);
        }

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.fixed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ringersoft/cdf.ringersoft.com/resources/views/inventory/goodsin/lc-cost.blade.php ENDPATH**/ ?>