<table class="table table-hover table-bordered">
    <thead>
    <tr>
        <th>#SL</th>
        <th>Name</th>
        <th>Phone</th>
        <th>Address</th>
        <th>Action</th>
    </tr>
    </thead>
    <tbody>
    <?php $i=0; ?>

    <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td> <?php echo e(++$i); ?> </td>
            <td> <?php echo e($supplier->name); ?> </td>
            <td> <?php echo e($supplier->phone); ?> </td>
            <td> <?php echo e($supplier->address); ?> </td>
            <td>
                <a href="<?php echo e(route('inventory.supplier.edit',$supplier->id)); ?>" class="btn btn-success fa fa-edit"></a> &nbsp; &nbsp;
                <a href="<?php echo e(route('parties.status',['type'=>'Supplier','related_party'=>$supplier->id])); ?>" class="btn btn-success">Ledger</a> &nbsp; &nbsp;
                <button type="button" class="fa fa-trash-alt btn btn-danger erase" data-id="<?php echo e($supplier->id); ?>" data-url="<?php echo e(route('inventory.supplier.destroy')); ?>"></button>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH /home/ringersoft/cdf.ringersoft.com/resources/views/inventory/supplier/suppliers-inventory.blade.php ENDPATH**/ ?>