<div class="table-responsive">
    <table class="table table-hover" id="ProunitTable">
        <thead>
            <tr>
                <td> #SL</td>
                <td> Name</td>
                <td> Description</td>
                <td> Action</td>
            </tr>
        </thead>

        <tbody>
            <?php $i=0; ?>
            <?php $__currentLoopData = $costs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$cost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e(++$i); ?></td>
                    <td> <?php echo e($cost->name); ?></td>
                    <td> <?php echo e($cost->description); ?></td>
                    <td>
                        <a href="<?php echo e(route('cost.edit',$cost->id)); ?>" class="btn btn-edit btn-success far fa-edit"></a>
                        <?php echo e(Form::button('',['class'=>'btn btn-danger fas fa-trash-alt erase','data-id'=>$cost->id,'data-url'=>route('cost.destroy')])); ?>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>
</div><?php /**PATH /home/ringersoft/cdf.ringersoft.com/resources/views/inventory/cost/costs.blade.php ENDPATH**/ ?>