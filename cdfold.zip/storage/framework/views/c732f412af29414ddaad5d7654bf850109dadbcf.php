

<?php $__env->startSection('title','Stock-Summary Inventory'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">

            </div>
        </div><!-- /.container-fluid -->
    </section>
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Manage Stock</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Manage Stock</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>


    <!-- Main content -->
    <section class="content">
        <div class="col-lg-12">

            <div class="card"><br>
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-12">
                            <h2 class="text-info text-center">STOCK REPORT</h2><hr>
                                <div class="row">
                                    

                                    <div class="col-lg-2">
                                        <div class="form-group">
                                            <?php echo e(Form::label('','Select Product')); ?>

                                            <?php echo e(Form::select('product_id',$products,false,['class'=>'form-control product_id ','data-type'=>3])); ?>


                                        </div>
                                    </div>
                                </div>


                            <hr>

                            <table class="table table-hover table-bordered" id="stockTable">
                                <thead>
                                    <tr>
                                        <th>#SL</th>
                                        <th>Name</th>
                                        <th>Department</th>
                                        <th>Group</th>
                                        <th>Qty</th>
                                    </tr>
                                </thead>
                                <tbody class="stockList">
                                <?php $sl=0; ?>

                                    <?php $__currentLoopData = $return_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    
                                        <tr>
                                            <td><?php echo e(++$sl); ?></td>
                                            <td><?php echo e($info['name']); ?></td>
                                            <td><?php echo e($info['department']); ?></td>
                                            <td><?php echo e($info['group']); ?></td>
                                            <td><?php echo e($info['qty']); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- /.content -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.10.20/css/dataTables.bootstrap4.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugin'); ?>
    <!-- DataTables -->
    <script src="https://cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.20/js/dataTables.bootstrap4.min.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- page script -->

    <script type="text/javascript">
        var table ;

        // $(document).ready(function () {
        //     table = $("#stockTable").DataTable();
        // });

        $(document).on('change','.product_id',function () {

            var product_id = $(this).val();
            var token = '<?php echo e(csrf_token()); ?>';

            // var department_id = $("SELECT[name='department_id']").val();
            // var group_id = $("SELECT[name='group_id']").val();

            if(product_id != ''){
                // table.clear().draw();
                // var tr = '<tr> <td colspan="5" class="bg-secondary text-center" style="padding: 10px;font-size: 1.3rem;text-transform: uppercase;font-weight: bold;letter-spacing: 28px;"> Stock Loading .... </td> </tr>';
                // $(".stockList").html(tr);
                $.ajax({
                    method:"post",
                    url:"<?php echo e(route('stock.retrive')); ?>",
                    data:{
                        product_id:product_id,
                        // department_id:department_id,
                        // group_id:group_id,
                        _token:token},
                    // dataType:'json',
                    success:function (res) {
                        $('#stockTable').html(res);
                        // if(res.success == 0){
                        //     var tr = '<tr> ' +
                        //         '<td colspan="5" class="bg-danger text-center" style="padding: 10px;font-size: 1.3rem;text-transform: uppercase;font-weight: bold;letter-spacing: 28px;">' +
                        //         ' Stock not available </td>' +
                        //         '</tr>';
                        //     $(".stockList").html(tr);
                        // }else{
                        //     var loop = res.success.sl.length-1;
                        //     for(i=0;i<=loop;i++){
                        //         table.row.add([
                        //             i+1,
                        //             res.success.name[i],
                        //             res.success.department[i],
                        //             res.success.group[i],
                        //             res.success.qty[i],
                        //         ]).draw();
                        //     }
                        // }
                    }
                });
            }
        });




        /* Comman Stock Hit */

        // $(document).on('change','.commonStock',function () {
        //     var id = $(this).val();
        //     var type = $(this).attr('data-type');
        //     var token = '<?php echo e(csrf_token()); ?>';

        //     if(id != ''){
        //         table.clear().draw();
        //         var tr = '<tr> <td colspan="5" class="bg-secondary text-center" style="padding: 10px;font-size: 1.3rem;text-transform: uppercase;font-weight: bold;letter-spacing: 28px;"> Stock Loading .... </td> </tr>';
        //         $(".stockList").html(tr);
        //         $.ajax({
        //             method:"post",
        //             url:"<?php echo e(route('cdf.stockreport')); ?>",
        //             data:{id:id,type:type,_token:token},
        //             dataType:'json',
        //             success:function (res) {
        //                 if(res.success == 0){

        //                     var tr = '<tr> <td colspan="5" class="bg-danger text-center" style="padding: 10px;font-size: 1.3rem;text-transform: uppercase;font-weight: bold;letter-spacing: 28px;"> Stock not available </td> </tr>';
        //                     $(".stockList").html(tr);
        //                 }else{
        //                     var loop = res.success.sl.length-1;
        //                     for(i=0;i<=loop;i++){
        //                         table.row.add([
        //                             i+1,
        //                             res.success.name[i],
        //                             res.success.department[i],
        //                             res.success.group[i],
        //                             res.success.qty[i],
        //                         ]).draw();
        //                     }
        //                 }

        //             }
        //         });

        //     }
        // });

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fixed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ringersoft/cdf.ringersoft.com/resources/views/inventory/stock/view-stock.blade.php ENDPATH**/ ?>