

<?php $__env->startSection('title','Employee - Inventory CDF '); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Manage  Employee  </h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Settings</a></li>
                        <li class="breadcrumb-item active">Manage Employee  </li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->


    <!-- Main content -->
    <section class="content">
        <div class="col-lg-12">
            <div class="row">
                <div class="col-md-12">
                    <div class="card card-warning card-outline">
                        <div class="card-header">
                            <div class="card-title">
                                <h5 class="text-info">Inventory Employee list </h5>
                                <p> <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#myModal">
                                    Add New Employee
                                  </button></p>
                            </div>

                            <div class="card-tools">
                                <button type="button" class="btn btn-tool" data-widget="collapse">
                                    <i class="fas fa-minus"></i>
                                </button>
                            </div>
                            <!-- /.card-tools -->
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body" style="display: block;">
                            <table class="table table-bordered table-striped" id="productTable">
                                <thead>
                                <tr>
                                    <th>SL</th>
                                    <th>Name</th>
                                    <th>Father </th>
                                    <th>Mother </th>
                                    <th>Email </th>
                                    <th>Nid </th>
                                    <th>Phone1 </th>
                                    <th>Salary </th>
                                    <th>Image </th>
                                    <th>Address</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $i=0; ?>
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr id="rowid<?php echo e($info->id); ?>" class="abcd">
                                        <td><?php echo e(++$i); ?></td>
                                        <td id="name<?php echo e($info->id); ?>" data-id="<?php echo e($info->name); ?>"><?php echo e($info->name); ?></td>
                                        <td id="name<?php echo e($info->id); ?>" data-id="<?php echo e($info->father); ?>"><?php echo e($info->father); ?></td>
                                        <td id="name<?php echo e($info->id); ?>" data-id="<?php echo e($info->mother); ?>"><?php echo e($info->mother); ?></td>
                                        <td id="name<?php echo e($info->id); ?>" data-id="<?php echo e($info->user ? $info->user->email :''); ?>"><?php echo e($info->user ? $info->user->email :'Access not Given'); ?></td>
                                        <td id="name<?php echo e($info->id); ?>" data-id="<?php echo e($info->nid); ?>"><?php echo e($info->nid); ?></td>
                                        <td id="name<?php echo e($info->id); ?>" data-id="<?php echo e($info->phone1); ?>"><?php echo e($info->phone1); ?></td>
                                        <td id="phone<?php echo e($info->id); ?>" data-id="<?php echo e($info->salary); ?>"><?php echo e($info->salary); ?></td>
                                        <td id="phone<?php echo e($info->id); ?>" data-id="<?php echo e($info->image); ?>"><img src="<?php echo e(asset('public/admin/employee/upload/'.$info->image)); ?>" style="height: 60px;width: 60px;"></td>
                                        <td id="address<?php echo e($info->id); ?>" data-id="<?php echo e($info->address); ?>">
                                            <?php if(!empty($info->address)): ?>
                                                <?php echo e(substr($info->address,0,10)); ?>

                                            <?php else: ?>
                                                <p class="text-center">no address</p>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a class="btn btn-sm btn-info edit" data-id="<?php echo e($info->id); ?>" href="<?php echo e(route('employee.edit',$info->id)); ?>"><i class="fa fa-pen"></i></a> ||
                                            <button class="btn btn-sm btn-danger erase" data-id="<?php echo e($info->id); ?>" data-url="<?php echo e(url('Employee/erase')); ?>">
                                                <i class="fa fa-trash"></i>
                                            </button>
                                            ||<a href="<?php echo e(route('parties.status',['type'=>'Customer','related_party'=>$info->user_id])); ?>" class="btn btn-success">Ledger</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                        <!-- /.card-body -->
                    </div>
                </div>
                

            </div>
        </div>
        <div class="modal fade" id="myModal">
            <div class="modal-dialog modal-lg">
              <div class="modal-content">
              
                <!-- Modal Header -->
                <div class="modal-header">
                  <h4 class="modal-title">Add Employee</h4>
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                
                <!-- Modal body -->
                <div class="modal-body">
                    <?php echo e(Form::open(['route'=>'employee.store','method'=>'post','id'=>'EmployeeForm','enctype'=>'multipart/form-data'])); ?>

                    <div class="row">
                        <div class="col-lg-12 col-sm-12 <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::hidden('id',null,['class'=>'form-control','id'=>'id'])); ?>

                            <?php echo e(Form::label('Employeename','Name : ',['class'=>'control-label'])); ?>

                            <?php echo e(Form::text('name',null,['class'=>'form-control','placeholder'=>'Ex: Employee Name','id'=>'name'])); ?>

                            <?php if($errors->has('name')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('name')); ?></strong>
                                </span>
                            <?php endif; ?>
                        
                        </div>
                    </div>
                   

                    

                    <div class="row">
                        <div class="col-lg-4 col-sm-4 <?php echo e($errors->has('father') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::label('Employeename','Father : ',['class'=>'control-label'])); ?>

                            <?php echo e(Form::text('father',old('father'),['class'=>'form-control','placeholder'=>'Ex: Father Name','id'=>'father'])); ?>

                            <?php if($errors->has('father')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('father')); ?></strong>
                                </span>
                            <?php endif; ?>
                           
                        </div>


                        <div class="col-lg-4 col-sm-4 <?php echo e($errors->has('mother') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::label('Mother','Mother : ',['class'=>'control-label'])); ?>

                            <?php echo e(Form::text('mother',old('mother'),['class'=>'form-control','placeholder'=>'Ex: Mother Name','id'=>'mother'])); ?>

                            <?php if($errors->has('mother')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('mother')); ?></strong>
                                </span>
                            <?php endif; ?>
                          
                        </div>


                        <div class="col-lg-4 col-sm-4 <?php echo e($errors->has('wife') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::label('Employeename','Wife : ',['class'=>'control-label'])); ?>

                            <?php echo e(Form::text('wife',old('wife'),['class'=>'form-control','placeholder'=>'Ex: wife Name','id'=>'name'])); ?>

                            <?php if($errors->has('wife')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('wife')); ?></strong>
                                </span>
                            <?php endif; ?>
                            
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-4 col-sm-4 <?php echo e($errors->has('salary') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::label('Employeename','Salary : ',['class'=>'control-label'])); ?>

                            <?php echo e(Form::text('salary',old('salary'),['class'=>'form-control','placeholder'=>'Ex: Salary','id'=>'salary'])); ?>

                            <?php if($errors->has('salary')): ?>
                                <span class="help-block">
                                        <strong><?php echo e($errors->first('salary')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group col-lg-4 col-sm-4 <?php echo e($errors->has('nid') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::label('Employeename','NID : ',['class'=>'control-label'])); ?>

                            <?php echo e(Form::text('nid',old('nid'),['class'=>'form-control','placeholder'=>'Ex: 6345678910645','id'=>'name'])); ?>

                            <?php if($errors->has('nid')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('nid')); ?></strong>
                                </span>
                            <?php endif; ?>
                            
                        </div>
                        <div class="form-group col-lg-4 col-sm-4 <?php echo e($errors->has('image') ? 'has-error' : ''); ?>">

                                <?php echo e(Form::label('Employeeimage','Image : ',['class'=>'control-label'])); ?>

                                <input type="file" name="image" id="image" class="form-control">
                                
                                <?php if($errors->has('image')): ?>
                                    <span class="help-block">
                                         <strong><?php echo e($errors->first('image')); ?></strong>
                                    </span>
                                <?php endif; ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-4 col-sm-4 <?php echo e($errors->has('phone1') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::label('Customername','Phone 1 : ',['class'=>'control-label'])); ?>

                            <?php echo e(Form::text('phone1',old('phone1'),['class'=>'form-control','placeholder'=>'Ex: Employee Phone 1','id'=>'name'])); ?>

                            <?php if($errors->has('phone1')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('phone1')); ?></strong>
                                </span>
                            <?php endif; ?>
                            
                        </div>
                        


                        <div class="col-lg-4 col-sm-4 <?php echo e($errors->has('phone2') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::label('Employeename','Phone 2 : ',['class'=>'control-label'])); ?>

                            <?php echo e(Form::text('phone2',old('phone2'),['class'=>'form-control','placeholder'=>'Ex: Employee Phone 2','id'=>'name'])); ?>

                            <?php if($errors->has('phone2')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('phone2')); ?></strong>
                                </span>
                            <?php endif; ?>
                        
                        </div>
                        <div class="col-lg-4 col-sm-4 <?php echo e($errors->has('phone1') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::label('Customername','Role : ',['class'=>'control-label'])); ?>

                           <select name="role" id="role">
                               <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></option>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                   
                               <?php endif; ?>
                           </select>
                            <?php if($errors->has('role')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('role')); ?></strong>
                                </span>
                            <?php endif; ?>
                            
                        </div>
                        
                    </div>
                    <div class="row">
                        <div class="form-group col-lg-6 col-sm-6 <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::label('Employeename','Email : ',['class'=>'control-label'])); ?>

                            <?php echo e(Form::email('email',null,['class'=>'form-control','placeholder'=>'Ex: Employee Email To give login Access','id'=>'email'])); ?>

                            <?php if($errors->has('email')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                </span>
                            <?php endif; ?>
                            
                        </div>
                        <div class="form-group col-lg-6 col-sm-6 <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
                            <?php echo e(Form::label('Employeename','Password : ',['class'=>'control-label'])); ?>

                            <input type="password" name="password" id="password" class="form-control">
                            
                            <?php if($errors->has('password')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
                            <?php endif; ?>
                            
                        </div>
                    </div>
                


                    <div class="row">
                        <div class="col-lg-12 col-sm-12 <?php echo e($errors->has('address') ? 'has-error' : ''); ?>">

                            <?php echo e(Form::label('Employeeaddress','Address : ',['class'=>'control-label'])); ?>

                            <?php echo e(Form::textarea('address',null,['class'=>'form-control','placeholder'=>'Ex: Employee Address','id'=>'address','rows'=>'3'])); ?>

                            <?php if($errors->has('address')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('address')); ?></strong>
                                </span>
                            <?php endif; ?>

                        </div>
                    </div>
                   

                   
                </div>
                
                <!-- Modal footer -->
                <div class="modal-footer">
                    
                        <?php echo e(Form::button('SAVE',['type'=>'submit','id'=>'saveCustomer','class'=>'btn btn-primary'])); ?>

                        <?php echo e(Form::hidden('canceledit',"Cancel Edit",['type'=>'reset','id'=>'cancel','class'=>'btn btn-danger'])); ?>

                   
                    <?php echo e(Form::close()); ?>

                  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
                
              </div>
            </div>
          </div>

    </section><!-- /.content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugin'); ?>
    <!-- DataTables -->
    <script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- page script -->
    <script type="text/javascript">
        var table;
        $(document).ready(function () {
            $('#productTable').dataTable();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.fixed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ringersoft/cdf.ringersoft.com/resources/views/admin/employee/add-employee.blade.php ENDPATH**/ ?>