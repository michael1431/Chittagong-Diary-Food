

<?php $__env->startSection('title','Manage Requisition - Purcahse Requisition'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">

            </div>
        </div><!-- /.container-fluid -->
    </section>
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Comparative Statement according to Quotation</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Manage Quotation Taken Lists</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>


    <!-- Main content -->
    <section class="content">
        <div class="col-lg-12">

            <div class="card"><br>
                <div class="card-body">
                    <div class="row">
                        
                        <div class="col-lg-12 table-responsive">

                                
                                <h4 class="text-left">Purchase Requisition : <?php echo e($requisition->id); ?> <p style="margin: 0" class="pull-right"> Date : <?php echo e(\Carbon\Carbon::parse($requisition->created_at)->format('d-m-Y')); ?> </p>  </h4>
                                <br>
                                <table class="table-bordered table-striped table">
                                    <thead>
                                    <tr>
                                        <th>#SL</th>
                                        <th>Item Code </th>
                                        <th>Item Name </th>
                                        <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sup=>$supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <th> <?php echo e($supplier[0]->supplier->name); ?>  </th>
                                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <th>Quotation Generate By</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                        <?php $i =0; $count = 0; ?>

                                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$cs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <tr>
                                            <?php if($count == 0): ?>
                                               <td><?php echo e(++$i); ?></td>
                                               <td><?php echo e($cs[$count]->requisitionProduct->product->item_code); ?></td>
                                               <td><?php echo e($cs[$count]->requisitionProduct->product->name); ?></td>

                                               <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sup=>$supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                   <?php
                                                        $pricing = \App\QuotationProduct::where('requisition_id',$requisition->id)->where('supplier_id',$supplier[0]->supplier_id)->where('requisition_product_id',$cs[$count]->requisition_product_id)->orderBy('price')->get();
                                                   ?>

                                                   
                                                    <?php $__currentLoopData = $pricing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <td> <?php echo e($price->price); ?> TK </td>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                   
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <td>  <?php echo e($cs[$count]->user->name); ?> </td>
                                            <?php endif; ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                

                        </div>
                    </div>
                    <button class="btn-primary btn cs" type="button" onclick="window.print()"> <i class="fa fa-print"></i> Print Comparative Statement</button>
                </div>

            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.css')); ?>">
    <style>
        @media  print {
            .cs {
                display: none;
            }
        }
    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugin'); ?>
    <!-- DataTables -->
    <script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.js')); ?>"></script>
    <!-- page script -->
    <script type="text/javascript">

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ringersoft/cdf.ringersoft.com/resources/views/inventory/purchase/comparative-statement.blade.php ENDPATH**/ ?>