<div class="row">
    <div class="col-md-12">
        <div class="form-group<?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
            <?php echo e(Form::label('', 'Item Name ', ['class'=>'label-control'])); ?>

            <?php echo e(Form::text('name',null,['class'=>'form-control','placeholder'=>'Ex. 1 No Amper Tube'])); ?>

            <?php if($errors->has('name')): ?>
            <p class="text-danger" id="success-alert">
                <?php echo e($errors->first('name')); ?>

            </p>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group<?php echo e($errors->has('item_code') ? 'has-error' : ''); ?>">
            <?php echo e(Form::label('', 'Item Code ', ['class'=>'label-control'])); ?>


            <?php echo e(Form::text('item_code',null,['class'=>'form-control','placeholder'=>'W#00001'])); ?>


            <?php if($errors->has('item_code')): ?>
            <p class="text-danger" id="success-alert">
                <?php echo e($errors->first('item_code')); ?>

            </p>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group<?php echo e($errors->has('product_unit_id') ? 'has-error' : ''); ?>">
            <?php echo e(Form::label('', 'Item Unit', ['class'=>'label-control'])); ?>

            <?php echo e(Form::select('product_unit_id',$units,null,['class'=>'form-control'])); ?>


            <?php if($errors->has('product_unit_id')): ?>
            <p class="text-danger" id="success-alert">
                <?php echo e($errors->first('product_unit_id')); ?>

            </p>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-md-6">

        <div class="form-group<?php echo e($errors->has('mrp') ? 'has-error' : ''); ?>">
            <?php echo e(Form::label('', 'Maximum Retail Price ', ['class'=>'label-control'])); ?>

            <?php echo e(Form::text('mrp',null,['class'=>'form-control','placeholder'=>'Ex. 50 TK'])); ?>

            <?php if($errors->has('mrp')): ?>
            <p class="text-danger" id="success-alert">
                <?php echo e($errors->first('mrp')); ?>

            </p>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group<?php echo e($errors->has('price') ? 'has-error' : ''); ?>">
            <?php echo e(Form::label('', 'Trade Price ', ['class'=>'label-control'])); ?>

            <?php echo e(Form::text('price',null,['class'=>'form-control','placeholder'=>'Ex. 50 TK'])); ?>

            <?php if($errors->has('price')): ?>
            <p class="text-danger" id="success-alert">
                <?php echo e($errors->first('price')); ?>

            </p>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group<?php echo e($errors->has('marketing_commission') ? 'has-error' : ''); ?>">
            <?php echo e(Form::label('', 'Marketing Commission', ['class'=>'label-control'])); ?>

            <?php echo e(Form::text('marketing_commission',null,['class'=>'form-control','placeholder'=>'Ex. 50 TK'])); ?>

            <?php if($errors->has('marketing_commission')): ?>
            <p class="text-danger" id="success-alert">
                <?php echo e($errors->first('marketing_commission')); ?>

            </p>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-md-6">
        <div class="form-group<?php echo e($errors->has('employee_commission') ? 'has-error' : ''); ?>">
            <?php echo e(Form::label('', 'Employee Commission', ['class'=>'label-control'])); ?>

            <?php echo e(Form::text('employee_commission',null,['class'=>'form-control','placeholder'=>'Ex. 50 TK'])); ?>

            <?php if($errors->has('employee_commission')): ?>
            <p class="text-danger" id="success-alert">
                <?php echo e($errors->first('employee_commission')); ?>

            </p>
            <?php endif; ?>
        </div>

    </div>
    <div class="col-md-6">
        <div class="form-group<?php echo e($errors->has('department_id') ? 'has-error' : ''); ?>">
            <?php echo e(Form::label('', 'ProductType', ['class'=>'label-control'])); ?>

            <?php echo e(Form::select('department_id',$departments,null,['class'=>'form-control'])); ?>


            <?php if($errors->has('department_id')): ?>
            <p class="text-danger" id="success-alert">
                <?php echo e($errors->first('department_id')); ?>

            </p>
            <?php endif; ?>
        </div>

    </div>
    <div class="col-md-6">

        <div class="form-group<?php echo e($errors->has('group_id') ? 'has-error' : ''); ?>">
            <?php echo e(Form::label('', 'Group', ['class'=>'label-control'])); ?>

            <?php echo e(Form::select('group_id',$groups,null,['class'=>'form-control'])); ?>


            <?php if($errors->has('group_id')): ?>
            <p class="text-danger" id="success-alert">
                <?php echo e($errors->first('group_id')); ?>

            </p>
            <?php endif; ?>
        </div>

    </div>
    <div class="col-md-12">



        <div class="form-group<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
            <?php echo e(Form::label('description', 'Description', ['class'=>'label-control'])); ?>

            <?php echo e(Form::textarea('description',old('description'),['class'=>'form-control','placeholder'=>'','rows'=>5,'cols'=>5])); ?>


            <?php if($errors->has('description')): ?>
            <span class="text-danger">
                <p> <?php echo e($errors->first('description')); ?> </p>
            </span>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-md-12">
        <div class="form-group row text-right">
            <div class="col-md-12">
                <a href="<?php echo e(URL::previous()); ?>">
                    <button class="btn btn-sm btn-danger">Back</button>
                </a>
                <button type="submit" class="btn btn-sm btn-success"><?php echo e($buttonText); ?></button>
                <input type="reset" value="Reset" class="btn btn-sm btn-warning">
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/ringersoft/cdf.ringersoft.com/resources/views/inventory/item/form-item-inventory.blade.php ENDPATH**/ ?>