<!-- Brand Logo -->
<a href="<?php echo e(url('/')); ?>" class="brand-link bg-info">
    <img src="<?php echo e(asset('favicon.png')); ?>" alt="AdminLTE Logo" class="brand-image img-circle elevation-3"
         style="opacity: .8">
    <span class="brand-text font-weight-light">Ringer ERP 1.0</span>
</a>

<!-- Sidebar -->
<div class="sidebar nano">
    <!-- Sidebar user panel (optional) -->
    <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
            <img src="<?php echo e(asset('cdfilogo.png')); ?>" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
            <a href="#" class="d-block"> Chittagong Dairy Food </a>
        </div>
    </div>

    <!-- Sidebar Menu -->
    <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
            <!-- Add icons to the links using the .nav-icon class
                 with font-awesome or any other icon font library -->
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            

            <li class="nav-item <?php echo e(isActive(['/','dashboard*'])); ?>">
                <a href="<?php echo e(action('DashboardController@index')); ?>" class="nav-link <?php echo e(isActive('/')); ?>">
                    <i class="nav-icon fas fa-tachometer-alt"></i>
                    <p>
                        Dashboard
                        
                    </p>
                </a>
            </li>

            

            

                    
                    <li class="nav-item has-treeview <?php echo e(isActive(['Employee*'])); ?>">
                        <a href="#" class="nav-link <?php echo e(isActive('Employee/*')); ?>">
                            <i class="fas fa-man"></i>
                            <p>User Management<i class="fas fa-angle-left right"></i> </p>
                        </a>
                       
                        <ul class="nav nav-treeview">
                            <?php if(hasPermission(Auth::user()->role_id,'employee.add')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('employee.add')); ?>" class="nav-link <?php echo e(isActive('Employee/add')); ?>">
                                    <p style="margin-left:30px">User List</p>
                                </a>
                            </li>
                            <?php endif; ?>
                        <?php if(hasPermission(Auth::user()->role_id,'user.roles.index')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('user.roles.index')); ?>" class="nav-link <?php echo e(isActive('Employee/roles-add')); ?>">
                                    <p style="margin-left:30px">Role Management</p>
                                </a>
                            </li>
                        <?php endif; ?>
                        </ul>
                        
                    </li>
                    <li class="nav-item has-treeview <?php echo e(isActive(['Inventory/add-inventory-department*','Inventory/add-inventory-group*','Inventory/add-inventory-unit*'])); ?>">
                        <a href="#" class="nav-link <?php echo e(isActive(['Inventory/add-inventory-department*','Inventory/add-inventory-group*','Inventory/add-inventory-unit*'])); ?>">
                            <i class="fas fa-tools"></i>
                            <p> Menu Setup<i class="fas fa-angle-left right"></i> </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if(hasPermission(Auth::user()->role_id,'warehouse.add')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('warehouse.add')); ?>" class="nav-link <?php echo e(isActive('add-warehouse')); ?>">
                                    <p style="margin-left:30px">Warehosue</p>
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(hasPermission(Auth::user()->role_id,'cost.add')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('cost.add')); ?>" class="nav-link <?php echo e(isActive('add-cost')); ?>">
                                    <p style="margin-left:30px">Cost Setup</p>
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(hasPermission(Auth::user()->role_id,'inventory.department.add')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('inventory.department.add')); ?>" class="nav-link <?php echo e(isActive('Inventory/add-inventory-department')); ?>">
                                    <p style="margin-left:30px">Product Type</p>
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(hasPermission(Auth::user()->role_id,'inventory.group.add')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('inventory.group.add')); ?>" class="nav-link <?php echo e(isActive('Inventory/add-inventory-group')); ?>">
                                    <p style="margin-left:30px">Group</p>
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(hasPermission(Auth::user()->role_id,'inventory.unit.add')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('inventory.unit.add')); ?>" class="nav-link <?php echo e(isActive('Inventory/add-inventory-unit')); ?>">
                                    <p style="margin-left:30px">Unit</p>
                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </li>

                    

                    

                    <li class="nav-item has-treeview <?php echo e(isActive(['Inventory/add-inventory-supplier'])); ?>">
                        <a href="#" class="nav-link <?php echo e(isActive('Inventory/add-inventory-supplier')); ?>">
                            <i class="fas fa-users"></i>
                            <p> Supplier Management<i class="fas fa-angle-left right"></i> </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if(hasPermission(Auth::user()->role_id,'inventory.supplier.add')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('inventory.supplier.add')); ?>" class="nav-link <?php echo e(isActive('Inventory/add-inventory-supplier')); ?>">
                                    <p style="margin-left:30px">Suppliers</p>
                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </li>

                    

                    
                    <li class="nav-item has-treeview <?php echo e(isActive(['Inventory/add-inventory-item*'])); ?>">
                        <a href="#" class="nav-link <?php echo e(isActive('settings/*')); ?>">
                            <i class="fas fa-sitemap"></i>
                            <p> Item Management<i class="fas fa-angle-left right"></i> </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if(hasPermission(Auth::user()->role_id,'inventory.item.add')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('inventory.item.add')); ?>" class="nav-link <?php echo e(isActive('Inventory/add-inventory-item')); ?>">
                                    <p style="margin-left:30px">Item Create & View </p>
                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </li>

                    

                    

                    <li class="nav-item has-treeview <?php echo e(isActive(['Inventory/add-inventory-requisition','Inventory/view-purchase-requisition*','Inventory/after-check-purchase-requisition'])); ?>">
                        <a href="#" class="nav-link <?php echo e(isActive(['Inventory/view-purchase-requisition/*','Inventory/add-inventory-requisition','Inventory/after-check-purchase-requisition'])); ?>">
                            <i class="fas fa-money"></i>
                            <p>Requisition Management<i class="fas fa-angle-left right"></i> </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if(hasPermission(Auth::user()->role_id,'inventory.requisition.add')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('inventory.requisition.add')); ?>" class="nav-link <?php echo e(isActive('Inventory/add-inventory-requisition')); ?>">
                                    <p style="margin-left:30px">Create Requisition</p>
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(hasPermission(Auth::user()->role_id,'inventory.purchase-requisition.view')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('inventory.purchase-requisition.view')); ?>" class="nav-link <?php echo e(isActive('Inventory/view-purchase-requisition')); ?>">
                                    <p style="margin-left:30px">All Requisition</p>
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(hasPermission(Auth::user()->role_id,'purchase.requisition.after.check')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('purchase.requisition.after.check')); ?>" class="nav-link <?php echo e(isActive('Inventory/after-check-purchase-requisition')); ?>">
                                    <p style="margin-left:30px">After Checking Requisition</p>
                                </a>

                            </li>
                            <?php endif; ?>
                        </ul>
                    </li>

                   

                    

                    
                    <li class="nav-item has-treeview <?php echo e(isActive(['Inventory/add-inventory-requisition-purchase*','Inventory/list-inventory-requisition-purchase*','Inventory/add-inventory-requisition-purchase*','Inventory/purchase-order*','Inventory/purchase-summary*','Inventory/requisition-quotation*'])); ?>">
                        <a href="#" class="nav-link <?php echo e(isActive(['Inventory/add-inventory-requisition-purchase*','Inventory/list-inventory-requisition-purchase*','Inventory/add-inventory-requisition-purchase*','Inventory/purchase-order*','Inventory/purchase-summary*','Inventory/requisition-quotation*'])); ?>">
                            <i class="fas fa-money"></i>
                            <p>Purchase Management<i class="fas fa-angle-left right"></i> </p>
                        </a>
                        <ul class="nav nav-treeview">
                            <?php if(hasPermission(Auth::user()->role_id,'inventory.requisition.purchase')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('inventory.requisition.purchase')); ?>" class="nav-link <?php echo e(isActive('Inventory/add-inventory-requisition-purchase')); ?>">
                                        <p style="margin-left:30px">Pending Purchase</p>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if(hasPermission(Auth::user()->role_id,'inventory.requisition.quotation.list')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('inventory.requisition.quotation.list')); ?>" class="nav-link <?php echo e(isActive('Inventory/requisition-quotation')); ?>">
                                    <p style="margin-left:30px">All Requisition Quotation</p>
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(hasPermission(Auth::user()->role_id,'inventory.order.purchase')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('inventory.order.purchase')); ?>" class="nav-link <?php echo e(isActive('Inventory/purchase-order')); ?>">
                                    <p style="margin-left:30px">Make Purchase Order </p>
                                </a>
                            </li>
                            <?php endif; ?>
                            <?php if(hasPermission(Auth::user()->role_id,'inventory.purchase.summary')): ?>
                            <li class="nav-item">
                                <a href="<?php echo e(route('inventory.purchase.summary')); ?>" class="nav-link <?php echo e(isActive('Inventory/purchase-summary')); ?>">
                                    <p style="margin-left:30px">Purchase Order Summary </p>
                                </a>
                            </li>
                            <?php endif; ?>
                        </ul>
                    </li>

                    
                    <li class="nav-item has-treeview <?php echo e(isActive(['Sales*'])); ?>">
                            <a href="#" class="nav-link <?php echo e(isActive('Sales/*')); ?>">
                                <i class="fas fa-money"></i>
                                <p> Order Management<i class="fas fa-angle-left right"></i> </p>
                            </a>
                            <ul class="nav nav-treeview">
    
                            <?php if(hasPermission(Auth::user()->role_id,'view-order')): ?>
                            <li class="nav-item">
                                    <a href="<?php echo e(route('view-order')); ?>" class="nav-link <?php echo e(isActive('Sales/view-order')); ?>">
                                        <p style="margin-left:30px">View Order List</p>
                                    </a>
                                </li>
                                <?php endif; ?>
                                <?php if(hasPermission(Auth::user()->role_id,'view-order')): ?>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('view-order',['custom_order=1'])); ?>" class="nav-link <?php echo e(isActive('Sales/view-order')); ?>">
                                        <p style="margin-left:30px">Create Order</p>
                                    </a>
                                
    
                                    
    
                                </li>
                                <?php endif; ?>
                            </ul>
                        </li>
                        


            
            <li class="nav-item has-treeview <?php echo e(isActive(['add-goodsin','lc-cost','goodsin_out_create'])); ?>">
                <a href="#" class="nav-link <?php echo e(isActive(['add-goodsin','lc-cost','goodsin_out_create'])); ?>">
                    <i class="fas fa-money"></i>
                    <p> Goods In Management<i class="fas fa-angle-left right"></i> </p>
                </a>
                <ul class="nav nav-treeview">
                <?php if(hasPermission(Auth::user()->role_id,'goodsin.add')): ?>
                <li class="nav-item">
                        <a href="<?php echo e(route('goodsin.add')); ?>" class="nav-link <?php echo e(isActive('add-goodsin')); ?>">
                            <p style="margin-left:30px">Add Goods In Stock</p>
                        </a>
                    </li>
                    <?php endif; ?>
                    <?php if(hasPermission(Auth::user()->role_id,'inventory.goodsin_out.create')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('inventory.goodsin_out.create')); ?>" class="nav-link <?php echo e(isActive('goodsin_out_create')); ?>">
                            <p style="margin-left:30px">Raw To FinishGoods</p>
                        </a>
                    </li>
                    <?php endif; ?>
                    <?php if(hasPermission(Auth::user()->role_id,'lc.cost')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('lc.cost')); ?>" class="nav-link <?php echo e(isActive('lc-cost')); ?>">
                            <p style="margin-left:30px">Expense Register</p>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </li>

            


            
            <li class="nav-item has-treeview <?php echo e(isActive(['lc-report','view-stock','Report/invoiceList','Report/Dues-Status','Report/IncomeExpense-Status','Report/Income-Status'])); ?>">
                <a href="#" class="nav-link <?php echo e(isActive(['lc-report','view-stock','Report/invoiceList','Report/Dues-Status','Report/IncomeExpense-Status','Report/Income-Status'])); ?>">
                    <i class="fas fa-money"></i>
                        <p>Reports<i class="fas fa-angle-left right"></i> </p>
                </a>
                <ul class="nav nav-treeview">
                   
                    <?php if(hasPermission(Auth::user()->role_id,'parties.status')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('parties.status')); ?>" class="nav-link <?php echo e(isActive('Report/Dues-Status')); ?>">
                            <p style="margin-left:30px">Dues Report </p>
                        </a>
                    </li>
                    <?php endif; ?>
                    <?php if(hasPermission(Auth::user()->role_id,'lc.report')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('lc.report')); ?>" class="nav-link <?php echo e(isActive('lc-report')); ?>">
                            <p style="margin-left:30px">LCwise Report </p>
                        </a>
                    </li>
                    <?php endif; ?>
                    <?php if(hasPermission(Auth::user()->role_id,'stock.view')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('stock.view')); ?>" class="nav-link <?php echo e(isActive('view-stock')); ?>">
                            <p style="margin-left:30px">Stock Status</p>
                        </a>
                    </li>
                    <?php endif; ?>
                    <?php if(hasPermission(Auth::user()->role_id,'invoice.list')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('invoice.list')); ?>" class="nav-link <?php echo e(isActive('Report/invoiceList')); ?>">
                            <p style="margin-left:30px">Invoice List</p>
                        </a>
                    </li>
                    <?php endif; ?>
                    <?php if(hasPermission(Auth::user()->role_id,'income_expense.status')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('income_expense.status')); ?>" class="nav-link <?php echo e(isActive('Report/IncomeExpense-Status')); ?>">
                            <p style="margin-left:30px">Income Status</p>
                        </a>
                    </li>
                    <?php endif; ?>
                    <?php if(hasPermission(Auth::user()->role_id,'income.status')): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(route('income.status')); ?>" class="nav-link <?php echo e(isActive('Report/Income-Status')); ?>">
                            <p style="margin-left:30px">Annual Income Statement</p>
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </li>


            
            


        </ul>
    </nav>
    <!-- /.sidebar-menu -->
</div>
<?php /**PATH /home/ringersoft/cdf.ringersoft.com/resources/views/includes/left-sidebar.blade.php ENDPATH**/ ?>