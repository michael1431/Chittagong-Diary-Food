

<?php $__env->startSection('title','Requisition Inventory'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Purchase Order</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Invoice</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <section class="content">
        <div class="container-fluid">
            <?php echo e(Form::open(['route'=>'inventory.purchase.store','method'=>'post','id'=>'PurchaseForm','class'=>'form-horizontal  '])); ?>

            <div class="row">

                <div class="col-lg-4">
                    <div class="form-group <?php echo e($errors->has('qty') ? 'has-error' : ''); ?> ">
                        <?php echo e(Form::label('','LC NO : ')); ?>

                        <?php echo e(Form::text('lc_no',null,['class'=>'form-control','placeholder'=>"LC302"])); ?>

            
                        <?php if($errors->has('qty')): ?>
                            <span class="">
                                <strong><?php echo e($errors->get('lc_no')); ?></strong>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('','Requisition Number')); ?>

                        <select name="requisition_id" class="form-control invoice_requisition_id">
                            <option value="0">Select Requisition Number</option>
                            <?php $__currentLoopData = $requisitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requisition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($requisition->id); ?>"> <?php echo e($requisition->id." -- ".$requisition->invoice_no); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <?php echo e(Form::label('','Quotation\'s')); ?>

                        <select name="quotation_id" class="form-control invoice_quotation_id">
                            <option value="0">Select Party Quotation</option>
                        </select>
                    </div>
                </div>

                <div class="col-lg-8">
                    <?php echo e(Form::label('','Purchase Confirmation Note : ')); ?>

                    <?php echo e(Form::textarea('note',null,['class'=>'form-control','rows'=>5,'cols'=>5,'placeholder'=>'Purchase order confirmation note......'])); ?>

                </div>

                <div class="col-lg-3">
                    <?php echo e(Form::submit('Confirm Purchase Order',['class'=>'form-control btn btn-info'])); ?>

                </div>

            </div><!-- /.row -->
            <?php echo e(Form::close()); ?>

        </div><!-- /.container-fluid -->
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugin'); ?>
    <!-- DataTables -->
    <script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- page script -->
    <script type="text/javascript">

        $(document).on('change','.invoice_requisition_id',function () {
            var requisition_id = $(this).val();

            $.ajax({
                method:"post",
                url:"<?php echo e(route('inventory.ajax-quotation-list')); ?>",
                data:{requisition_id:requisition_id,_token:"<?php echo e(csrf_token()); ?>"},
                dataType:"html",
                success:function (response) {
                    $('.invoice_quotation_id').html(response);
                }
            });
        });

        $("#PurchaseForm").submit(function (e) {
            e.preventDefault();
                $.ajax({
                    method:"post",
                    url:"<?php echo e(route('inventory.purchase.store')); ?>",
                    data: $(this).serialize(),
                    dataType:"json",
                    success:function (response) {
                        if (response.success == 1){
                            $.notify("Purchase order Successfully complete", {globalPosition: 'top center',className: 'success'});
                            $('.invoice_quotation_id').html('');

                        }
                        $(this).reset();
                    }
                });
        });

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fixed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ringersoft/cdf.ringersoft.com/resources/views/inventory/purchase/purchase-order.blade.php ENDPATH**/ ?>