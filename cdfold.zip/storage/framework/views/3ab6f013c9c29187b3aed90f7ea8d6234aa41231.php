<div class="table-responsive">
    <table class="table table-hover" id="productTable">
        <thead>
            <tr>
                <td> #SL</td>
                <td>Roles</td>
                <td> Permissions</td>
                <td> Action</td>
            </tr>
        </thead>

        <tbody id="tbodyItem">
            <?php $i=0; ?>
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e(++$i); ?></td>
                    <td> <?php echo e($info->name); ?></td>
                    <td>
                        <?php $__empty_1 = true; $__currentLoopData = $info->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <span class="badge badge-info"><?php echo e($permission->lebel); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('users.roles.edit',$info->id)); ?>" class="btn btn-edit btn-success far fa-edit"></a>
                        <?php echo e(Form::button('',['class'=>'btn btn-danger fas fa-trash-alt erase','data-id'=>$info->id,'data-url'=>route('users.roles.destroy')])); ?>


                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>


</div><?php /**PATH /home/ringersoft/cdf.ringersoft.com/resources/views/users/roles-list.blade.php ENDPATH**/ ?>