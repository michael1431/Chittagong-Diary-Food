

<?php $__env->startSection('title','Transform Inventory'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Inventory Transform</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Inventory Transform</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <section class="content">
        <div class="container-fluid">
            <?php echo e(Form::open(['route'=>'inventory.goodsin_out.store','method'=>'post','id'=>'PurchaseForm','class'=>'form-horizontal'])); ?>

            <div class="row">

                <div class="col-lg-4">
                    <div class="form-group">
                    <?php if(!request('consume_product') && !request('damage_product')): ?>
                    <a href="<?php echo e(route('inventory.goodsin_out.create',['consume_product=1'])); ?>" class="btn btn-info btn-xs">Consume Product</a>
                    <a href="<?php echo e(route('inventory.goodsin_out.create',['damage_product=1'])); ?>" class="btn btn-info btn-xs">Damage Product</a>
                    <?php else: ?>
                    <a href="<?php echo e(route('inventory.goodsin_out.create')); ?>" class="btn btn-info btn-xs">Add FinishedGoods from RawGoods</a>
                    <?php endif; ?>
                    </div>
                    <?php if(request('consume_product')): ?>
                    <div class="form-group">
                        <?php echo e(Form::label('','Employee')); ?>

                        <select name="emp_id" class="form-control">
                            <option value="0">Select Employee</option>
                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($employee->id); ?>"> <?php echo e($employee->name." -- ".$employee->phone1); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('','Consume Product')); ?>

                        <select name="consume_product_id" class="form-control" required>
                            <option value="0">Select Product</option>
                            <?php $__currentLoopData = $consumableProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(($product->accesories->sum('stock_in_qty') - $product->accesories->sum('stock_out_qty') ) > 0): ?>
                                    <option value="<?php echo e($product->id); ?>"> <?php echo e($product->id." -- ".$product->name." -- ".($product->accesories->sum('stock_in_qty') - $product->accesories->sum('stock_out_qty'))); ?>

                                     </option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php endif; ?>
                    <?php if(!request('consume_product') && !request('damage_product')): ?>
                    <div class="form-group" id="raw_product_option" style="display:block">
                        <?php echo e(Form::label('','Raw Product')); ?>

                        <select name="raw_product_id" class="form-control" required>
                            <option value="0">Select Product To be Convert Into Finished Goods</option>
                            <?php $__currentLoopData = $stockedProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(($product->stocks) && ( $product->stocks->sum('qty') - $product->stocks->sum('stock_out_qty') ) > 0): ?>
                                    <option value="<?php echo e($product->id); ?>"> <?php echo e($product->id." -- ".$product->name." -- ".($product->stocks->sum('qty')-$product->stocks->sum('stock_out_qty'))); ?></option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php endif; ?>
                   
                    <div class="form-group">
                        <?php if(!request('damage_product')): ?>
                        <?php echo e(Form::label('','StockOut Qty')); ?>

                        <input type="number" name="stock_out_qty" class="form-control">
                        <?php endif; ?>
                            <?php if(request('consume_product')): ?>
                                <input type="hidden" name="consume_product" value="1">
                            <?php endif; ?>
                            <?php if(request('damage_product')): ?>
                                <input type="hidden" name="damage_product" value="1">
                            <?php endif; ?>
                    </div>
                    <?php if(!request('consume_product')): ?>
                    <div class="form-group">
                        <?php echo e(Form::label('',request('damage_product')?'Damage Product':'Finished Product')); ?>

                        <select name="finished_product_id" class="form-control" required>
                            <option value="0">Finished Goods</option>
                            <?php $__currentLoopData = $finishGoods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $finishGood): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($finishGood->id); ?>"> <?php echo e($finishGood->id." -- ".$finishGood->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('',request('damage_product')?'Damage Goods Qty':'Finish Goods Qty')); ?>

                        <input type="number" name="stock_in_qty" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::label('',request('damage_product')?'Price':'CostOfGoods per Qty')); ?>

                        <input type="number" name="price" class="form-control" required>
                    </div>
                    <?php endif; ?>
                </div>

                <div class="col-lg-8">
                    <?php echo e(Form::label('','Stock Transformation Note : ')); ?>

                    <?php echo e(Form::textarea('note',null,['class'=>'form-control','rows'=>5,'cols'=>5,'placeholder'=>'Stock Transformation Note......'])); ?>

                </div>

                <div class="col-lg-3">
                    <?php echo e(Form::submit('Confirm Stock Transform',['class'=>'form-control btn btn-info'])); ?>

                </div>

            </div><!-- /.row -->
            <?php echo e(Form::close()); ?>

        </div><!-- /.container-fluid -->
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugin'); ?>
    <!-- DataTables -->
    <script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- page script -->
    <script type="text/javascript">

        function empToggle() {
           var type= document.getElementById("stock_out_type").value;
           //alert(type);
            if(type=='2'){
                document.getElementById("emp_option").style.display ='block';
                document.getElementById("lc_cost_option").style.display ='none';
                $("#amount").attr('readonly',true);

            }else if(type=='3'){
                document.getElementById("qty_option").style.display ='none';
                document.getElementById("lc_cost_option").style.display ='block';
                $("#amount").attr('readonly',false);
            }else{
                document.getElementById("qty_option").style.display ='none';
                document.getElementById("lc_cost_option").style.display ='none';
                $("#amount").attr('readonly',false);
            }     
        }

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fixed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ringersoft/cdf.ringersoft.com/resources/views/inventory/goodsout/inventory-convert.blade.php ENDPATH**/ ?>