

<?php $__env->startSection('title','Requisition Inventory'); ?>

<?php $__env->startSection('content'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">

            </div>
        </div><!-- /.container-fluid -->
    </section>
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Manage Requisition</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Manage Requisition</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>


    <!-- Main content -->
    <section class="content">
        <div class="col-lg-12">

            <div class="card"><br>
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-12 table-responsive">
                            <div class="table-responsive">
                                <table class="table table-hover table-striped table-bordered">
                                    <thead>
                                        <tr class="bg-info">
                                            <td> #SL</td>
                                            <td> Invoice No</td>
                                            <td> LC No</td>
                                            <td> Requisition No</td>
                                            <td> Supplier / Party</td>
                                            <td> Quotation No </td>
                                            <td> Authorized By</td>
                                            <td> Date & Time</td>
                                            <td> Ordered Duration </td>
                                            <td> Action </td>
                                        </tr>
                                    </thead>

                                    <tbody class="bodyItem" id="requisition_items">
                                    <?php $i= 0; ?>
                                    <?php if($purchases->count()>0): ?>
                                        <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td> <?php echo e(++$i); ?> </td>
                                                <td> <?php echo e($purchase->invoice_no); ?> </td>
                                                <td> <?php echo e($purchase->invoice ? $purchase->invoice->lc_no :''); ?> </td>
                                                <td> <?php echo e($purchase->requisition_id); ?> </td>
                                                <td>
                                                    <label class="btn btn-dark btn-block">
                                                        <?php echo e($purchase->quotation->supplier->name ." -- ".$purchase->quotation->supplier->phone); ?>

                                                    </label>
                                                </td>
                                                <td> <?php echo e($purchase->quotation_id); ?> </td>
                                                <td> <label class="btn btn-primary btn-block"> <?php echo e($purchase->user->name); ?> </label> </td>
                                                <td> <?php echo e(\Carbon\Carbon::parse($purchase->created_at)->format('d-M-Y -- h:i:s A')); ?> </td>
                                                <td> <?php echo e($purchase->created_at->diffForHumans()); ?> </td>
                                                <td> <a href="<?php echo e(route('inventory.purchase.print',$purchase->id)); ?>" target="_blank" class="btn btn-info">Print</a> </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="12" class=" bg-danger text-center"> No Requisition Product found</td>
                                        </tr>
                                    <?php endif; ?>
                                    </tbody>
                                </table>

                                <br>
                                <br>
                                <br>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- /.content -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugin'); ?>
    <!-- DataTables -->
    <script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- page script -->
    <script type="text/javascript">

        $(document).ready(function () {
            window.setTimeout(function() {
                $(".alert").slideUp(1000, function(){
                    $(this).remove();
                });
            }, 1200);

        });
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fixed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ringersoft/cdf.ringersoft.com/resources/views/inventory/purchase/summary-purchase.blade.php ENDPATH**/ ?>