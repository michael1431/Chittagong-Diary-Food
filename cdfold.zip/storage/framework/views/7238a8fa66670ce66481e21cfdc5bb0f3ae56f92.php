

<?php $__env->startSection('title','Invoice list -CDF'); ?>
<?php $__env->startSection('style'); ?>
    <style>
        .check_label{
            padding: 5px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">

            </div>
        </div><!-- /.container-fluid -->
    </section>
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>All Invoice</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Invoice List</li>
                    </ol>
                    <button type="button" class="btn btn-info pull-right" data-toggle="modal" data-target="#myModal">
                        Edit Invoice Date
                      </button>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>


    <!-- Main content -->
    <section class="content">
        <div class="col-lg-12">

            <div class="card"><br>
                <div class="card-body">
                    <div class="row">
                        
                        <div class="col-lg-12 table-responsive">

                            <table class="table-bordered table-striped table">
                                <thead>
                                    <th>#SL</th>
                                    <th>Date</th>
                                    <th>Invoice No</th>
                                    <th>Party</th>
                                    <th>Event</th>
                                    <th>Total</th>                                    
                                    <th>Commission</th>                                   
                                    <th>Paid/Received</th>
                                    <th>Action</th>
                                </thead>

                               
                                <tbody>
                                    <?php 
                                        $i=0;
                                        $total=0;
                                    ?>
                                    <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <tr>
                                            <td><?php echo e(++$i); ?></td>
                                            <td><?php echo e(date('d-m-Y',strtotime($invoice_info->created_at))); ?></td>
                                            <td><?php echo e($invoice_info->invoice_no); ?></td>
                                            
                                            <?php if($invoice_info->related_party_type !== null && $invoice_info->related_party_type == 'Customer'): ?>
                                                <td><strong class="badge badge-success"> Customer </strong>  <?php echo e($invoice_info->order_by->name ?? 'N/A'); ?></td>
                                              
                                            <?php elseif($invoice_info->related_party_type !== null && $invoice_info->related_party_type == 'Supplier'): ?>
                                                <td><strong class="badge badge-info"> Supplier </strong>   <?php echo e($invoice_info->supplier->name ?? 'N/A'); ?></td>

                                            <?php elseif($invoice_info->related_party_type !== null && $invoice_info->related_party_type == 'Employee'): ?>
                                                <td><strong class="badge badge-warning"> Employee </strong>   <?php echo e($invoice_info->employee->name ?? 'N/A'); ?></td>
                                    
                                            <?php else: ?>
                                                <td>
                                                    <strong class="badge badge-danger"> Expenses </strong>
                                                    <?php echo e($invoice_info->cost->name ?? 'N/A'); ?>

                                                   
                                                </td>
                                            <?php endif; ?>
                                            
                                            <td><?php echo e(strtoupper($invoice_info->event)); ?></td>
                                            <td><?php echo e($invoice_info->total_amount); ?></td>
                                            <td><?php echo e($invoice_info->total_discount); ?></td>
                                            
                                            <td><?php echo e($invoice_info->total_paid); ?></td>
                                            
                                            <td>
                                                    <a href="<?php echo e(route('invoice.print',$invoice_info->id)); ?>" class="btn btn-info"><i class="fa fa-eye"></i></a>
                                                    

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                            </table>
                            <?php echo e($invoices->appends(request()->input())->render()); ?>

                        </div>
                        

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- /.content -->
 <!-- The Modal -->
 <div class="modal" id="myModal">
    <div class="modal-dialog">
      <div class="modal-content">
  
        <!-- Modal Header -->
        <div class="modal-header">
          <h4 class="modal-title">Edit Invoice Date</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
  
        <!-- Modal body -->
        <form method="POST" action="<?php echo e(route('lc.reportFind')); ?>"
                accept-charset="UTF-8" class="form-horizontal">
        <div class="modal-body">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="" class="label-control">Set Date </label>
                            <input class="form-control" name="created_at" type="datetime" placeholder="YYYY-MM-DD">
                            <input type="hidden" name="invoice_edit" value="1">
                        </div>
                    </div>
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="" class="label-control">Item Unit</label>
                            <select class="form-control select2-hidden-accessible" name="invoice_id[]" tabindex="-1"
                                aria-hidden="true" multiple>
                                <?php $__empty_1 = true; $__currentLoopData = $invoice_options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->id); ?>  <?php echo e($item->invoice_no); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    
                                <?php endif; ?>
                               
                            </select>
                        </div>
                    </div>
                    <div class="col-md-12">
                        
                    </div>
                </div>
          
        </div>
  
        <!-- Modal footer -->
        <div class="modal-footer">
         
          <div class="form-group row text-right">
            <div class="col-md-12">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-sm btn-success">Update</button>
            </div>
        </div>
        </div>
    </form>
  
      </div>
    </div>
  </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <!-- DataTables -->
    <link rel="stylesheet" href="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('plugin'); ?>
    <!-- DataTables -->
    <script src="<?php echo e(asset('plugins/datatables/jquery.dataTables.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/datatables/dataTables.bootstrap4.js')); ?>"></script>

    <!-- page script -->
    <script type="text/javascript">

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.fixed', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ringersoft/cdf.ringersoft.com/resources/views/admin/invoice/invoice-list.blade.php ENDPATH**/ ?>