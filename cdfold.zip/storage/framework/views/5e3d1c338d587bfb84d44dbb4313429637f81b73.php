<div class="table-responsive">
    <table class="table table-hover" id="InventoryDepartMentTable">
        <thead>
            <tr>
                <td> #SL</td>
                <td> Name</td>
                <td> Description</td>
                <td> Action</td>
            </tr>
        </thead>

        <tbody>
            <?php $i=0; ?>
            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e(++$i); ?></td>
                    <td> <?php echo e($group->name); ?></td>
                    <td> <?php echo e($group->description); ?></td>
                    <td>
                        <a href="<?php echo e(route('inventory.group.edit',$group->id)); ?>" class="btn btn-edit btn-success far fa-edit"></a>
                        <?php echo e(Form::button('',['class'=>'btn btn-danger fas fa-trash-alt erase','data-id'=>$group->id,'data-url'=>route('inventory.group.destroy')])); ?>


                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>

    </table>
</div><?php /**PATH /home/ringersoft/cdf.ringersoft.com/resources/views/inventory/group/groups-inventory.blade.php ENDPATH**/ ?>