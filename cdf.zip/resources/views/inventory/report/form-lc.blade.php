<div class="col-lg-12">
    <div class="form-group">
        {{ Form::label('','LC No : ') }}
        <select name="lc_no" id="lc_no" required>
            @foreach ($lcs as $lc)
                @if ($lc)
                    <option value="{{$lc}}">{{$lc}}</option>
                 @endif
            @endforeach

        </select>
        {{-- {{ Form::select('lc_no',$lcs,null,['class'=>'form-control goodsin_id']) }} --}}
    </div>
</div>


<div class="col-lg-12">
    <div class="form-group">
        {{ Form::button($buttonText,['class'=>'btn btn-success getGoodsIn']) }}
    </div>
</div>