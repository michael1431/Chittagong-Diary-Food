<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SalaryStatement extends Model
{
    //
}
